import { useContext, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Checkbox } from "primereact/checkbox";
import { Divider } from "primereact/divider";
import { Dropdown } from "primereact/dropdown";
import { InputText } from "primereact/inputtext";
import { InputTextarea } from "primereact/inputtextarea";
import { Toast } from "primereact/toast";
import ContextoUsuário from "../../contextos/contexto-usuário";
import ContextoGerenteHospital from "../../contextos/contexto-gerente-hospital";
import { serviçoCadastrarReservaAla, serviçoRemoverReservaAla } from "../../serviços/serviços-gerente-hospital";
import mostrarToast from "../../utilitários/mostrar-toast";
import { MostrarMensagemErro, checarListaVazia, validarCamposObrigatórios }
    from "../../utilitários/validações";
import { 
    estilizarBotão, estilizarBotãoRetornar, estilizarBotãoRemover, estilizarCard,
    estilizarCheckbox, estilizarDivCampo, estilizarDivider, estilizarDropdown, estilizarFlex, 
    estilizarInlineFlex, estilizarInputText, estilizarInputTextarea, estilizarLabel
} from "../../utilitários/estilos";

export default function CadastrarReservaAla() {
    const referênciaToast = useRef(null);
    const { usuárioLogado } = useContext(ContextoUsuário);
    const { reservaAlaConsultada, tratamentoExperimentalSelecionado } = useContext(ContextoGerenteHospital);

    const [dados, setDados] = useState({
        id_tratamento_experimental: tratamentoExperimentalSelecionado?.id || reservaAlaConsultada?.tratamento_experimental?.id || "",
        temporária: reservaAlaConsultada?.temporária || false,
        justificativa: reservaAlaConsultada?.justificativa || "",
        prioridade: reservaAlaConsultada?.prioridade || "",
        id_sala: reservaAlaConsultada?.id_sala || "",
        número_leitos_reservados: reservaAlaConsultada?.número_leitos_reservados || null,
        data_reserva: reservaAlaConsultada?.data_reserva || ""
    });
    
    const [erros, setErros] = useState({});
    const navegar = useNavigate();

    const opçõesPrioridade = [
        { label: "Urgente", value: "urgente" },
        { label: "Alta", value: "alta" },
        { label: "Média", value: "media" },
        { label: "Baixa", value: "baixa" }
    ];

    function alterarEstado(event) {
        const chave = event.target.name;
        const valor = event.checked ?? event.target.value;
        setDados({ ...dados, [chave]: valor });
    };

    function validarCampos() {
        const { justificativa, prioridade, id_sala, número_leitos_reservados, data_reserva } = dados;
        let errosCamposObrigatórios = validarCamposObrigatórios({ justificativa, prioridade, id_sala, número_leitos_reservados, data_reserva });
        
        if (!dados.id_tratamento_experimental) {
            errosCamposObrigatórios.id_tratamento_experimental = "É obrigatório selecionar um Tratamento Experimental";
        }

        setErros(errosCamposObrigatórios);
        return checarListaVazia(errosCamposObrigatórios);
    };

    function tratamentoExperimentalLabel() {
        if (reservaAlaConsultada?.tratamento_experimental || tratamentoExperimentalSelecionado)
            return "Tratamento Experimental Selecionado*:";
        else return "Selecione um Tratamento Experimental*:";
    };

    function pesquisarTratamentosExperimentais() { navegar("../pesquisar-tratamentos-experimentais"); };
    function retornarAdministrarReservasAla() { navegar("../administrar-reservas-ala"); };

    async function cadastrarReservaAla() {
        if (validarCampos()) {
            try {
                await serviçoCadastrarReservaAla({ ...dados, cpf: usuárioLogado.cpf });
                mostrarToast(referênciaToast, "Reserva de Ala cadastrada com sucesso!", "sucesso");
            } catch (error) { mostrarToast(referênciaToast, error.response.data.erro, "erro"); }
        }
    };

    async function removerReservaAla() {
        try {
            await serviçoRemoverReservaAla(reservaAlaConsultada.id);
            mostrarToast(referênciaToast, "Reserva de Ala removida com sucesso!", "sucesso");
        } catch (error) { mostrarToast(referênciaToast, error.response.data.erro, "erro"); }
    };

    function BotõesAções() {
        if (reservaAlaConsultada) {
            return (
                <div className={estilizarInlineFlex()}>
                    <Button className={estilizarBotãoRetornar()} label="Retornar"
                        onClick={retornarAdministrarReservasAla} />
                    <Button className={estilizarBotãoRemover()} label="Remover" onClick={removerReservaAla} />
                </div>
            );
        } else {
            return (
                <div className={estilizarInlineFlex()}>
                    <Button className={estilizarBotãoRetornar()} label="Retornar"
                        onClick={retornarAdministrarReservasAla} />
                    <Button className={estilizarBotão()} label="Cadastrar" onClick={cadastrarReservaAla} />
                </div>
            );
        }
    };

    function tituloFormulario() {
        if (reservaAlaConsultada) return "Remover Reserva de Ala";
        else return "Cadastrar Reserva de Ala";
    };

    function TratamentoExperimentalInputText() {
        const titulo = tratamentoExperimentalSelecionado?.título || reservaAlaConsultada?.tratamento_experimental?.título;
        if (titulo) {
            return <InputText name="título_tratamento_experimental"
                className={estilizarInputText(erros.id_tratamento_experimental, 400, usuárioLogado.cor_tema)}
                value={titulo} disabled />
        }
        return null;
    };

    function BotãoSelecionar() {
        if (!tratamentoExperimentalSelecionado && !reservaAlaConsultada)
            return <Button className={estilizarBotão()} label="Selecionar" onClick={pesquisarTratamentosExperimentais} />
        else if (tratamentoExperimentalSelecionado) {
            return <Button className={estilizarBotão()} label="Substituir" onClick={pesquisarTratamentosExperimentais} />;
        }
        else return null;
    };

    return (
        <div className={estilizarFlex()}>
            <Toast ref={referênciaToast} onHide={retornarAdministrarReservasAla} position="bottom-center" />
            <Card title={tituloFormulario()} className={estilizarCard(usuárioLogado.cor_tema)}>
                
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>{tratamentoExperimentalLabel()}</label>
                    <BotãoSelecionar />
                    <TratamentoExperimentalInputText />
                    <MostrarMensagemErro mensagem={erros.id_tratamento_experimental} />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>ID da Sala*:</label>
                    <InputText name="id_sala" value={dados.id_sala}
                        className={estilizarInputText(erros.id_sala, 200, usuárioLogado.cor_tema)}
                        onChange={alterarEstado} disabled={!!reservaAlaConsultada} />
                    <MostrarMensagemErro mensagem={erros.id_sala} />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Leitos Reservados*:</label>
                    <InputText name="número_leitos_reservados" value={dados.número_leitos_reservados}
                        className={estilizarInputText(erros.número_leitos_reservados, 200, usuárioLogado.cor_tema)}
                        onChange={alterarEstado} disabled={!!reservaAlaConsultada} keyfilter="int" />
                    <MostrarMensagemErro mensagem={erros.número_leitos_reservados} />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Data da Reserva*:</label>
                    <InputText name="data_reserva" type="date" value={dados.data_reserva}
                        className={estilizarInputText(erros.data_reserva, 200, usuárioLogado.cor_tema)}
                        onChange={alterarEstado} disabled={!!reservaAlaConsultada} />
                    <MostrarMensagemErro mensagem={erros.data_reserva} />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Prioridade*:</label>
                    <Dropdown name="prioridade"
                        className={estilizarDropdown(erros.prioridade, usuárioLogado.cor_tema)}
                        value={dados.prioridade} options={opçõesPrioridade} onChange={alterarEstado}
                        placeholder="-- Selecione --" 
                        disabled={!!reservaAlaConsultada} />
                    <MostrarMensagemErro mensagem={erros.prioridade} />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Reserva Temporária:</label>
                    <Checkbox name="temporária" checked={dados.temporária}
                        className={estilizarCheckbox()} onChange={alterarEstado} 
                        disabled={!!reservaAlaConsultada} />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Justificativa*:</label>
                    <InputTextarea name="justificativa" value={dados.justificativa}
                        className={estilizarInputTextarea(erros.justificativa, usuárioLogado.cor_tema)}
                        onChange={alterarEstado} autoResize cols={40} 
                        disabled={!!reservaAlaConsultada} />
                    <MostrarMensagemErro mensagem={erros.justificativa} />
                </div>

                <Divider className={estilizarDivider()} />
                <BotõesAções />
            </Card>
        </div>
    );
}