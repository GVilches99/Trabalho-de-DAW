import { useContext, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Toast } from "primereact/toast";
import ContextoUsuário from "../../contextos/contexto-usuário";
import { serviçoAlterarUsuário, serviçoRemoverUsuário } from "../../serviços/serviços-usuário";
import mostrarToast from "../../utilitários/mostrar-toast";
import {
    estilizarBotão, estilizarBotãoRemover, estilizarDivCampo, estilizarInlineFlex,
    estilizarLabel, estilizarModal
} from "../../utilitários/estilos";

export default function ModalConfirmaçãoUsuário() {
    const referênciaToast = useRef(null);
    const { usuárioLogado, setUsuárioLogado, confirmaçãoUsuário, setConfirmaçãoUsuário, setMostrarModalConfirmação } = useContext(ContextoUsuário);
    const navegar = useNavigate();
    const [redirecionar, setRedirecionar] = useState(false);

    const dados = {
        cpf: confirmaçãoUsuário?.cpf,
        perfil: confirmaçãoUsuário?.perfil,
        nome: confirmaçãoUsuário?.nome,
        email: confirmaçãoUsuário?.email,
        senha: confirmaçãoUsuário?.senha,
        questão: confirmaçãoUsuário?.questão,
        resposta: confirmaçãoUsuário?.resposta,
        cor_tema: confirmaçãoUsuário?.cor_tema
    };

    function labelOperação() {
        switch (confirmaçãoUsuário?.operação) {
            case "salvar": return "Salvar";
            case "alterar": return "Alterar";
            case "remover": return "Remover";
            default: return;
        }
    };

    function exibirPerfilFormatado() {
        switch (dados.perfil) {
            case "chefe_laboratório": return "Chefe de Laboratório";
            case "gerente_hospital": return "Gerente de Hospital";
            default: return "";
        }
    };

    function finalizarCadastro() {
        if (dados.perfil === "chefe_laboratório") {
            setUsuárioLogado({ ...dados, cadastrado: false });
            setMostrarModalConfirmação(false);
            navegar("../cadastrar-chefe-laboratório");
        } else if (dados.perfil === "gerente_hospital") {
            setUsuárioLogado({ ...dados, cadastrado: false });
            setMostrarModalConfirmação(false);
            navegar("../cadastrar-gerente-hospital");
        }
    };

    async function alterarUsuário() {
        try {
            const dadosAlterados = {
                email: dados.email,
                senha: dados.senha,
                questão: dados.questão,
                resposta: dados.resposta,
                cor_tema: dados.cor_tema
            };
            const response = await serviçoAlterarUsuário({ ...dadosAlterados, cpf: usuárioLogado.cpf });
            setUsuárioLogado({ ...usuárioLogado, ...response.data });
            setRedirecionar(true);
            mostrarToast(referênciaToast, "Alterado com sucesso! Redirecionando à Página Inicial...", "sucesso");
        } catch (error) {
            mostrarToast(referênciaToast, error.response.data.erro, "erro");
        }
    };

    async function removerUsuário() {
        try {
            await serviçoRemoverUsuário(usuárioLogado.cpf);
            setRedirecionar(true);
            mostrarToast(referênciaToast, "Removido com sucesso! Redirecionando ao Login.", "sucesso");
        } catch (error) {
            mostrarToast(referênciaToast, error.response.data.erro, "erro");
        }
    };

    function executarOperação() {
        switch (confirmaçãoUsuário.operação) {
            case "salvar":
                finalizarCadastro();
                break;
            case "alterar":
                alterarUsuário();
                break;
            case "remover":
                removerUsuário();
                break;
            default: break;
        }
    };

    function ocultar() {
        setConfirmaçãoUsuário({});
        setMostrarModalConfirmação(false);
    };

    function fecharToast() {
        if (redirecionar) {
            setMostrarModalConfirmação(false);
            setConfirmaçãoUsuário({});
            if (confirmaçãoUsuário?.operação === 'remover') {
                setUsuárioLogado(null);
                navegar("/");
            } else {
                navegar("../pagina-inicial");
            }
        }
    }

    return (
        <div className={estilizarModal()}>
            <Toast ref={referênciaToast} onHide={fecharToast} position="bottom-center" />
            <div className={estilizarDivCampo()}>
                <label className={estilizarLabel(confirmaçãoUsuário?.cor_tema)}>Tipo de Perfil:</label>
                <label>{exibirPerfilFormatado()}</label>
            </div>
            <div className={estilizarDivCampo()}>
                <label className={estilizarLabel(confirmaçãoUsuário?.cor_tema)}>CPF -- nome de usuário:</label>
                <label>{dados.cpf}</label>
            </div>
            <div className={estilizarDivCampo()}>
                <label className={estilizarLabel(confirmaçãoUsuário?.cor_tema)}>Nome Completo:</label>
                <label>{dados.nome}</label>
            </div>
            <div className={estilizarDivCampo()}>
                <label className={estilizarLabel(confirmaçãoUsuário?.cor_tema)}>Email:</label>
                <label>{dados.email}</label>
            </div>
            <div className={estilizarDivCampo()}>
                <label className={estilizarLabel(confirmaçãoUsuário?.cor_tema)}>Questão de Segurança:</label>
                <label>{dados.questão}</label>
            </div>
            <div className={estilizarDivCampo()}>
                <label className={estilizarLabel(confirmaçãoUsuário?.cor_tema)}>Resposta:</label>
                <label>{dados.resposta}</label>
            </div>

            <div className={estilizarInlineFlex()}>
                <Button label={labelOperação()} onClick={executarOperação}
                    className={estilizarBotão(confirmaçãoUsuário?.cor_tema)} />
                <Button label="Corrigir" onClick={ocultar}
                    className={estilizarBotãoRemover(confirmaçãoUsuário?.cor_tema)} />
            </div>
        </div>
    );
}