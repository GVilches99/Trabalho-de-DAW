import { BaseEntity, Column, Entity, PrimaryGeneratedColumn, ManyToOne, JoinColumn } from "typeorm";
import GerenteHospital from "./gerente-hospital";
import TratamentoExperimental from "./tratamento-experimental";


// Enum para o novo atributo
export enum PrioridadeReserva {
    URGENTE = "urgente",
    ALTA = "alta",
    MEDIA = "media",
    BAIXA = "baixa"
}

@Entity("reserva_ala") // Define o nome da tabela
export default class ReservaAla extends BaseEntity { // <-- DEVE ESTENDER BASEENTITY
    @PrimaryGeneratedColumn()
    id: number;

    // --- Colunas do seu 'espec.pdf' original ---
    @Column()
    id_sala: string;

    @Column()
    número_leitos_reservados: number;

    @Column({ type: "date" })
    data_reserva: Date;

    // --- Colunas exigidas pelo Tutorial 3 ---
    @Column()
    justificativa: string;

    @Column()
    temporária: boolean;

    @Column({ type: "enum", enum: PrioridadeReserva })
    prioridade: PrioridadeReserva;

    // --- Relações ---
    @ManyToOne(() => GerenteHospital, (gerente_hospital) => gerente_hospital.reservas_ala, { onDelete: "CASCADE" })
    @JoinColumn({ name: 'gerente_hospital_id' })
    gerente_hospital: GerenteHospital;

    @ManyToOne(() => TratamentoExperimental, (tratamento) => tratamento.reservas_ala, { onDelete: "CASCADE" })
    @JoinColumn({ name: 'tratamento_experimental_id' })
    tratamento_experimental: TratamentoExperimental;
}