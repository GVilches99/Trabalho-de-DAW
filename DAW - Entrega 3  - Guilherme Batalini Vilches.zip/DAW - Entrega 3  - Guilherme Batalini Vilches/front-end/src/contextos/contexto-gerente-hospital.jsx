import { createContext, useState } from "react";

const ContextoGerenteHospital = createContext();
export default ContextoGerenteHospital;

export function ProvedorGerenteHospital({ children }) {
    const [reservaAlaConsultada, setReservaAlaConsultada] = useState({});
    const [tratamentoExperimentalConsultado, setTratamentoExperimentalConsultado] = useState({});
    const [tratamentoExperimentalSelecionado, setTratamentoExperimentalSelecionado] = useState({});
    const [tratamentoExperimentalDaReserva, setTratamentoExperimentalDaReserva] = useState({});

    return (
        <ContextoGerenteHospital.Provider value={{
            reservaAlaConsultada, setReservaAlaConsultada,
            tratamentoExperimentalConsultado, setTratamentoExperimentalConsultado,
            tratamentoExperimentalSelecionado, setTratamentoExperimentalSelecionado,
            tratamentoExperimentalDaReserva, setTratamentoExperimentalDaReserva
        }}>
            {children}
        </ContextoGerenteHospital.Provider>
    );
}