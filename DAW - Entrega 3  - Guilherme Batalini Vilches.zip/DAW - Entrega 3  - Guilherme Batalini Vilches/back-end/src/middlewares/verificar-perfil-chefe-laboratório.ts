import { Perfil } from "../entidades/usuário";
export default function verificarPerfilChefeLaboratório(request, response, next) {
    if (request.perfil === Perfil.CHEFE_LABORATÓRIO) { // Corrigido para usar o nome exato da chave do enum
        return next();
    } else {
        return response.status(401).json({ erro: "Acesso não autorizado." });
    }
};