import { createContext, useState } from "react";

const ContextoGerenteHospital = createContext();
export default ContextoGerenteHospital;

export function ProvedorGerenteHospital({ children }) {
    const [reservaAlaConsultada, setReservaAlaConsultada] = useState({});
    const [tratamentoExperimentalConsultado, setTratamentoExperimentalConsultado] = useState({});
    const [tratamentoExperimentalSelecionado, setTratamentoExperimentalSelecionado] = useState({});
    const [tratamentoExperimentalDaReserva, setTratamentoExperimentalDaReserva] = useState({});
    const [chefeLaboratorioProponente, setChefeLaboratorioProponente] = useState({});

    return (
        <ContextoGerenteHospital.Provider value={{
            reservaAlaConsultada, setReservaAlaConsultada,
            tratamentoExperimentalConsultado, setTratamentoExperimentalConsultado,
            tratamentoExperimentalSelecionado, setTratamentoExperimentalSelecionado,
            tratamentoExperimentalDaReserva, setTratamentoExperimentalDaReserva,
            chefeLaboratorioProponente, setChefeLaboratorioProponente
        }}>
            {children}
        </ContextoGerenteHospital.Provider>
    );
}