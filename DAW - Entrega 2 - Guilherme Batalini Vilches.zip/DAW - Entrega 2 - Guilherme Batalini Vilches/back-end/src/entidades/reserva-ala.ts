import { BaseEntity, Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from
    "typeorm";
import GerenteHospital from "./gerente-hospital";
import TratamentoExperimental from "./tratamento-experimental";
@Entity("reserva_ala") 
export default class ReservaAla extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;
    @Column()
    id_sala: string;
    @Column()
    número_leitos_reservados: number;
    @Column()
    justificativa: string;
    @Column()
    temporária: boolean;
    @CreateDateColumn()
    data_reserva: Date;
    @ManyToOne(() => TratamentoExperimental, (tratamento_experimental) => tratamento_experimental.reservas_ala, { onDelete: "CASCADE" })
    @JoinColumn({ name: 'tratamento_experimental_id' }) 
    tratamento_experimental: TratamentoExperimental;
    @ManyToOne(() => GerenteHospital, (gerente_hospital) => gerente_hospital.reservas_ala, { onDelete: "CASCADE" })
    @JoinColumn({ name: 'gerente_hospital_id' }) 
    gerente_hospital: GerenteHospital;
}