import servidor from "./servidor";

export function serviçoCadastrarChefeLaboratório(dadosChefeLaboratório) {
    return servidor.post("/chefes-laboratorio", dadosChefeLaboratório);
};

export function serviçoBuscarChefeLaboratório(cpf) {
    return servidor.get(`/chefes-laboratorio/${cpf}`);
};

export function serviçoAtualizarChefeLaboratório(dadosChefeLaboratório) {
    return servidor.patch("/chefes-laboratorio", dadosChefeLaboratório);
};