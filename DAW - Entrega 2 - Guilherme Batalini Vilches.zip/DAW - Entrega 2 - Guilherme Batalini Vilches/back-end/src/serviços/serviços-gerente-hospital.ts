import md5 from "md5";
import { getManager } from "typeorm";
import Usuário, { Status } from "../entidades/usuário";
import GerenteHospital from '../entidades/gerente-hospital';
import ServiçosUsuário from "./serviços-usuário";

export default class ServiçosGerenteHospital {
    constructor() { }

    static async cadastrarGerenteHospital(request, response) {
        try {
            const { usuário_info, nome_hospital, capacidade_leitos, tipo_hospital, especialidade_médica } = request.body;
            const { usuário, token } = await ServiçosUsuário.cadastrarUsuário(usuário_info);
            const entityManager = getManager();

            await entityManager.transaction(async (transactionManager) => {
                await transactionManager.save(usuário);
                const gerente_hospital = GerenteHospital.create({ usuário, nome_hospital, capacidade_leitos, tipo_hospital, especialidade_médica });
                await transactionManager.save(gerente_hospital);
                await transactionManager.update(Usuário, usuário.cpf, { status: Status.ATIVO });
                return response.json({ status: Status.ATIVO, token });
            });
        } catch (error) { 
            return response.status(500).json({ erro: error.message }); 
        }
    };

    static async atualizarGerenteHospital(request, response) {
        try {
            const { cpf, nome_hospital, capacidade_leitos, tipo_hospital, especialidade_médica } = request.body;
            const cpf_encriptado = md5(cpf);
            await GerenteHospital.update({ usuário: { cpf: cpf_encriptado } }, { nome_hospital, capacidade_leitos, tipo_hospital, especialidade_médica });
            return response.json();
        } catch (error) { 
            return response.status(500).json({ erro: "Erro no BD ao atualizar Gerente de Hospital" }); 
        }
    };

    static async buscarGerenteHospital(request, response) {
        try {
            const cpf_encriptado = md5(request.params.cpf);
            const gerente_hospital = await GerenteHospital.findOne({ 
                where: { usuário: cpf_encriptado },
                relations: ["usuário"] 
            });

            if (!gerente_hospital) return response.status(404).json({ erro: "Gerente de Hospital não encontrado." });
            return response.json({ 
                nome: gerente_hospital.usuário.nome, 
                email: gerente_hospital.usuário.email,
                nome_hospital: gerente_hospital.nome_hospital,
                capacidade_leitos: gerente_hospital.capacidade_leitos,
                tipo_hospital: gerente_hospital.tipo_hospital,
                especialidade_médica: gerente_hospital.especialidade_médica
            });
        } catch (error) { 
            return response.status(500).json({ erro: "Erro no BD ao buscar Gerente de Hospital" }); 
        }
    };
}