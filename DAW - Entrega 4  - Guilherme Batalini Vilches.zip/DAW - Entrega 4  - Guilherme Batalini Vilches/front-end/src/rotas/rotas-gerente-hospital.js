import { useContext } from "react";
import { Navigate, Outlet } from "react-router-dom";
import ContextoUsuário from "../contextos/contexto-usuário";

export default function RotasGerenteHospital() {
    const { usuárioLogado } = useContext(ContextoUsuário);
    if (usuárioLogado.perfil === "gerente_hospital") return <Outlet />
    else return <Navigate to="/" />;
}