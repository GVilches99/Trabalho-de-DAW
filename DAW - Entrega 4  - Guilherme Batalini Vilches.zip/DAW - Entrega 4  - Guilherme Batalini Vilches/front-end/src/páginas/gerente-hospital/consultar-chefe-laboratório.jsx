import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Divider } from "primereact/divider";
import { InputNumber } from "primereact/inputnumber";
import { InputText } from "primereact/inputtext";
import ContextoUsuário from "../../contextos/contexto-usuário";
import ContextoGerenteHospital from "../../contextos/contexto-gerente-hospital";
import { estilizarBotãoRetornar, estilizarCard, estilizarDivCampo, estilizarDivider, estilizarFlex,
    estilizarInlineFlex, estilizarInputText, estilizarLabel } from "../../utilitários/estilos";

export default function ConsultarChefeLaboratorio() {
    const { usuárioLogado } = useContext(ContextoUsuário);
    const { chefeLaboratorioProponente } = useContext(ContextoGerenteHospital);
    
    const dados = {
        nome_chefe_laboratorio: chefeLaboratorioProponente?.usuário?.nome,
        instituição_pesquisa: chefeLaboratorioProponente?.instituição_pesquisa,
        anos_experiência_pesquisa: chefeLaboratorioProponente?.anos_experiência_pesquisa,
        área_formação: chefeLaboratorioProponente?.área_formação
    };
    const navegar = useNavigate();

    function retornarConsultarTratamentoExperimental() { 
        navegar("../consultar-tratamento-experimental"); 
    };

    return (
        <div className={estilizarFlex()}>
            <Card title="Consultar Chefe de Laboratório" className={estilizarCard(usuárioLogado.cor_tema)}>
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Chefe de Laboratório*:</label>
                    <InputText name="nome_chefe_laboratorio"
                        className={estilizarInputText(null, 400, usuárioLogado.cor_tema)}
                        value={dados.nome_chefe_laboratorio} disabled />
                </div>
                
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Instituição de Pesquisa*:</label>
                    <InputText name="instituição_pesquisa"
                        className={estilizarInputText(null, 300, usuárioLogado.cor_tema)}
                        value={dados.instituição_pesquisa} autoResize disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Anos de Experiência*:</label>
                    <InputNumber name="anos_experiência_pesquisa"
                        value={dados.anos_experiência_pesquisa}
                        inputClassName={estilizarInputText(null, 50, usuárioLogado.cor_tema)}
                        mode="decimal" min={0} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Área de Formação*:</label>
                    <InputText name="área_formação"
                        className={estilizarInputText(null, 200, usuárioLogado.cor_tema)}
                        value={dados.área_formação} autoResize disabled />
                </div>

                <Divider className={estilizarDivider(usuárioLogado.cor_tema)} />
                <div className={estilizarInlineFlex()}>
                    <Button className={estilizarBotãoRetornar()} label="Retornar"
                        onClick={retornarConsultarTratamentoExperimental} />
                </div>
            </Card>
        </div>
    );
};