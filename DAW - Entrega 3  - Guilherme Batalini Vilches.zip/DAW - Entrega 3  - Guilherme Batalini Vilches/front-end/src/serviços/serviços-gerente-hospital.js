import servidor from "./servidor";

// Funções da Entrega 2
export function serviçoCadastrarGerenteHospital(dadosGerenteHospital) {
    return servidor.post("/gerentes-hospital", dadosGerenteHospital);
};

export function serviçoBuscarGerenteHospital(cpf) {
    return servidor.get(`/gerentes-hospital/${cpf}`);
};

export function serviçoAtualizarGerenteHospital(dadosGerenteHospital) {
    return servidor.patch("/gerentes-hospital", dadosGerenteHospital);
};

// Funções da Entrega 3
export function serviçoCadastrarReservaAla(reserva_ala) {
    return servidor.post("/gerentes-hospital/reservas-ala", reserva_ala);
};

export function serviçoRemoverReservaAla(id) {
    return servidor.delete(`/gerentes-hospital/reservas-ala/${id}`);
};

export function serviçoBuscarReservasAlaGerenteHospital(cpf) {
    return servidor.get(`/gerentes-hospital/reservas-ala/gerente-hospital/${cpf}`);
};

export function serviçoBuscarTratamentosExperimentais() {
    return servidor.get("/gerentes-hospital/reservas-ala/tratamentos-experimentais");
};