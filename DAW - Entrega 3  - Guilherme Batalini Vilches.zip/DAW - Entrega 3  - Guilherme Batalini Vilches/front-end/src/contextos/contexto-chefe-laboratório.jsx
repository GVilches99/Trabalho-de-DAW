import { createContext, useState } from "react";

const ContextoChefeLaboratório = createContext();
export default ContextoChefeLaboratório;

export function ProvedorChefeLaboratório({ children }) {
    const [tratamentoExperimentalConsultado, setTratamentoExperimentalConsultado] = useState({});

    return (
        <ContextoChefeLaboratório.Provider value={{ 
            tratamentoExperimentalConsultado, setTratamentoExperimentalConsultado 
        }}>
            {children}
        </ContextoChefeLaboratório.Provider>
    );
}