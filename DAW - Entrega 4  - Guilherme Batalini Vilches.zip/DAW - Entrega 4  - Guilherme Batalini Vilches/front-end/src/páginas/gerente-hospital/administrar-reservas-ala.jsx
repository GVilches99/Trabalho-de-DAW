import { useContext, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Divider } from "primereact/divider";
import { Dropdown } from "primereact/dropdown";
import { Toast } from "primereact/toast";
import { TriStateCheckbox } from "primereact/tristatecheckbox";
import ContextoUsuário from "../../contextos/contexto-usuário";
import ContextoGerenteHospital from "../../contextos/contexto-gerente-hospital";
import { serviçoBuscarReservasAlaGerenteHospital } from "../../serviços/serviços-gerente-hospital";
import mostrarToast from "../../utilitários/mostrar-toast";
import { 
    TAMANHOS, estilizarBotão, estilizarBotãoRetornar, estilizarBotãoTabela, estilizarCard,
    estilizarColumnHeader, estilizarColunaConsultar, estilizarDataTable, estilizarDataTablePaginator,
    estilizarDivider, estilizarFilterMenu, estilizarFlex, estilizarTriStateCheckbox 
} from "../../utilitários/estilos";

export default function AdministrarReservasAla() {
    const referênciaToast = useRef(null);
    const { usuárioLogado } = useContext(ContextoUsuário);
    const { reservaAlaConsultada, setReservaAlaConsultada, setTratamentoExperimentalSelecionado } 
        = useContext(ContextoGerenteHospital);
    const [listaReservasAla, setListaReservasAla] = useState([]);
    const navegar = useNavigate();

    const opçõesTipoCâncerAlvo = [
        { label: "Pulmão", value: "pulmão" },
        { label: "Mama", value: "mama" },
        { label: "Próstata", value: "próstata" },
        { label: "Leucemia", value: "leucemia" },
        { label: "Pele", value: "pele" }
    ];

    function retornarPáginaInicial() { navegar("/pagina-inicial"); };

    function adicionarReservaAla() {
        setReservaAlaConsultada(null);
        setTratamentoExperimentalSelecionado(null);
        navegar("../cadastrar-reserva-ala");
    };

    function ConsultarTemplate(reserva_ala) {
        function consultar() {
            setReservaAlaConsultada(reserva_ala);
            setTratamentoExperimentalSelecionado(null);
            navegar("../cadastrar-reserva-ala");
        };
        return (
            <Button icon="pi pi-search"
                className={estilizarBotãoTabela(usuárioLogado.cor_tema,
                    reservaAlaConsultada?.id === reserva_ala.id)}
                tooltip="Consultar Reserva de Ala" tooltipOptions={{ position: 'top' }} onClick={consultar} />
        );
    };

    function DropdownTipoCâncerTemplate(opções) {
        function alterarFiltroDropdown(event) {
            return opções.filterCallback(event.value, opções.index);
        };
        return <Dropdown value={opções.value} options={opçõesTipoCâncerAlvo} placeholder="Selecione"
            onChange={alterarFiltroDropdown} showClear />;
    };

    function BooleanBodyTemplate(reserva_ala) {
        if (reserva_ala.temporária) return "Sim";
        else return "Não";
    };

    function BooleanFilterTemplate(opções) {
        function alterarFiltroTriState(event) { return opções.filterCallback(event.value); };
        return (
            <div>
                <label>Reserva Temporária:</label>
                <TriStateCheckbox
                    className={estilizarTriStateCheckbox(usuárioLogado?.cor_tema)} value={opções.value}
                    onChange={alterarFiltroTriState} />
            </div>
        );
    };

    useEffect(() => {
        let desmontado = false;
        async function buscarReservasAlaGerenteHospital() {
            try {
                const response = await serviçoBuscarReservasAlaGerenteHospital(usuárioLogado.cpf);
                if (!desmontado && response.data) setListaReservasAla(response.data);
            } catch (error) { 
                mostrarToast(referênciaToast, error.response.data.erro, "error"); 
            }
        }
        buscarReservasAlaGerenteHospital();
        return () => desmontado = true;
    }, [usuárioLogado.cpf]);

    return (
        <div className={estilizarFlex()}>
            <Toast ref={referênciaToast} position="bottom-center" />
            <Card title="Administrar Reservas de Ala" className={estilizarCard(usuárioLogado.cor_tema)}>
                <DataTable dataKey="id" size="small" paginator rows={TAMANHOS.MAX_LINHAS_TABELA}
                    emptyMessage="Nenhuma reserva de ala encontrada." value={listaReservasAla}
                    responsiveLayout="scroll" breakpoint="490px" removableSort
                    className={estilizarDataTable()}
                    paginatorClassName={estilizarDataTablePaginator(usuárioLogado.cor_tema)}>
                    
                    <Column bodyClassName={estilizarColunaConsultar()} body={ConsultarTemplate}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} />
                    
                    <Column field="tratamento_experimental.chefe_laboratório.usuário.nome" header="Chefe de Laboratório" filter
                        showFilterOperator={false}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} sortable />
                    
                    <Column headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)}
                        field="tratamento_experimental.tipo_câncer_alvo" header="Tipo de Câncer Alvo" filter filterMatchMode="equals"
                        filterElement={DropdownTipoCâncerTemplate} showClearButton={false}
                        showFilterOperator={false} showFilterMatchModes={false}
                        filterMenuClassName={estilizarFilterMenu()} showFilterMenuOptions={false} sortable />
                    
                    <Column field="tratamento_experimental.título" header="Tratamento Experimental" filter showFilterOperator={false}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} sortable />
                    
                    <Column field="temporária" header="Temporária" dataType="boolean" filter
                        showFilterOperator={false} body={BooleanBodyTemplate}
                        filterElement={BooleanFilterTemplate} filterMatchMode="equals" showClearButton={false}
                        showAddButton={false} filterMenuClassName={estilizarFilterMenu()}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} sortable />
                </DataTable>
                
                <Divider className={estilizarDivider()} />
                <Button className={estilizarBotãoRetornar()} label="Retornar"
                    onClick={retornarPáginaInicial} />
                <Button className={estilizarBotão()} label="Adicionar" onClick={adicionarReservaAla} />
            </Card>
        </div>
    );
}