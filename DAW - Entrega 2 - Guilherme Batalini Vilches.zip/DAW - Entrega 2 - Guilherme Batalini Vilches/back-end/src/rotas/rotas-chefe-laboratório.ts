import { Router } from "express";
import verificarToken from "../middlewares/verificar-token";
import verificarPerfilChefeLaboratório from "../middlewares/verificar-perfil-chefe-laboratório";
import ServiçosChefeLaboratório from "../serviços/serviços-chefe-laboratório";
const RotasChefeLaboratório = Router();
export default RotasChefeLaboratório;
RotasChefeLaboratório.post("/", ServiçosChefeLaboratório.cadastrarChefeLaboratório);
RotasChefeLaboratório.get("/:cpf", 
    verificarToken, 
    verificarPerfilChefeLaboratório,
    ServiçosChefeLaboratório.buscarChefeLaboratório
);
 RotasChefeLaboratório.patch("/", verificarToken, verificarPerfilChefeLaboratório, 
   ServiçosChefeLaboratório.atualizarChefeLaboratório);