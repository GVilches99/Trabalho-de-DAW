import { useContext, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Divider } from "primereact/divider";
import { Dropdown } from "primereact/dropdown";
import { InputText } from "primereact/inputtext";
import { InputNumber } from "primereact/inputnumber";
import { Toast } from "primereact/toast";
import ContextoUsuário from "../../contextos/contexto-usuário";
import { serviçoCadastrarChefeLaboratório, serviçoBuscarChefeLaboratório, serviçoAtualizarChefeLaboratório }
    from "../../serviços/serviços-chefe-laboratório";
import mostrarToast from "../../utilitários/mostrar-toast";
import { MostrarMensagemErro, checarListaVazia, validarCamposObrigatórios }
    from "../../utilitários/validações";
import {
    estilizarBotão, estilizarBotãoRetornar, estilizarCard, estilizarDivCampo, estilizarDivider,estilizarDropdown,
    estilizarFlex, estilizarInlineFlex, estilizarInputNumber, estilizarInputText, estilizarLabel
}
    from "../../utilitários/estilos";

export default function CadastrarChefeLaboratório() {
    const referênciaToast = useRef(null);
    const { usuárioLogado, setUsuárioLogado } = useContext(ContextoUsuário);
    const [dados, setDados] = useState({ instituição_pesquisa: "", anos_experiência_pesquisa: null, área_formação: "" });
    const [erros, setErros] = useState({});
    const [cpfExistente, setCpfExistente] = useState(false);
    const navegar = useNavigate();

    const opçõesÁreaFormação = [
    { label: "Medicina", value: "medicina" },
    { label: "Biologia", value: "biologia" },
    { label: "Química", value: "química" },
    { label: "Farmácia", value: "farmácia" },
    { label: "Biomedicina", value: "biomedicina" }
];

    function alterarEstado(event) {
        const chave = event.target.name;
        const valor = event.target.value;
        setDados({ ...dados, [chave]: valor });
    };

    function validarCampos() {
        const errosCamposObrigatórios = validarCamposObrigatórios(dados);
        setErros(errosCamposObrigatórios);
        return checarListaVazia(errosCamposObrigatórios);
    };

    function títuloFormulário() {
        if (usuárioLogado?.cadastrado) return "Alterar Chefe de Laboratório";
        else return "Cadastrar Chefe de Laboratório";
    };

    // Corrigido: Função de atualizar definida corretamente como 'async'
    async function atualizarChefeLaboratório() {
        if (validarCampos()) {
            try {
                const response = await serviçoAtualizarChefeLaboratório({ ...dados, cpf: usuárioLogado.cpf });
                if (response) mostrarToast(referênciaToast, "Chefe de Laboratório atualizado com sucesso!", "sucesso");
            } catch (error) {
                mostrarToast(referênciaToast, error.response.data.erro, "erro");
            }
        }
    };

    // Corrigido: Removido o código duplicado e malformado que estava aqui

    async function cadastrarChefeLaboratório() {
        if (validarCampos()) {
            try {
                const response = await serviçoCadastrarChefeLaboratório({ ...dados, usuário_info: usuárioLogado });
                if (response.data)
                    setUsuárioLogado(usuário => ({
                        ...usuário, status: response.data.status,
                        token: response.data.token
                    }));
                mostrarToast(referênciaToast, "Chefe de Laboratório cadastrado com sucesso!", "sucesso");
            } catch (error) {
                setCpfExistente(true);
                mostrarToast(referênciaToast, error.response.data.erro, "erro");
            }
        }
    };

    function labelBotãoSalvar() {
        if (usuárioLogado?.cadastrado) return "Alterar";
        else return "Cadastrar";
    };

    function açãoBotãoSalvar() {
        if (usuárioLogado?.cadastrado) {
            atualizarChefeLaboratório(); // Chamada correta
        } else {
            cadastrarChefeLaboratório();
        }
    };

    function redirecionar() {
        if (cpfExistente) {
            setUsuárioLogado(null);
            navegar("/criar-usuario");
        } else {
            // Apenas navega, não precisa alterar o 'usuárioLogado' aqui
            setUsuárioLogado(usuárioLogado => ({ ...usuárioLogado, cadastrado: true }));
            navegar("/pagina-inicial");
        }
    };

    useEffect(() => {
        let desmontado = false;
        async function buscarDadosChefeLaboratório() {
            try {
                const response = await serviçoBuscarChefeLaboratório(usuárioLogado.cpf);
                if (!desmontado && response.data) {
                    setDados(response.data);
                }
            } catch (error) {
                const erro = error.response.data.erro;
                if (erro) mostrarToast(referênciaToast, erro, "erro");
            }
        }
        if (usuárioLogado?.cadastrado) {
            buscarDadosChefeLaboratório();
        }
        return () => desmontado = true;
    }, [usuárioLogado?.cadastrado, usuárioLogado.cpf]);

    return (
        <div className={estilizarFlex()}>
            <Toast ref={referênciaToast} onHide={redirecionar} position="bottom-center" />
            <Card title={títuloFormulário()} className={estilizarCard(usuárioLogado.cor_tema)}>
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Instituição de Pesquisa*:</label>
                    <InputText name="instituição_pesquisa" value={dados.instituição_pesquisa} onChange={alterarEstado}
                        className={estilizarInputText(erros.instituição_pesquisa, 400, usuárioLogado.cor_tema)} />
                    <MostrarMensagemErro mensagem={erros.instituição_pesquisa} />
                </div>
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Anos de Experiência em Pesquisa*:</label>
                    <InputNumber name="anos_experiência_pesquisa"
                        value={dados.anos_experiência_pesquisa}
                        onValueChange={(e) => alterarEstado({ target: { name: 'anos_experiência_pesquisa', value: e.value } })} mode="decimal"
                        inputClassName={estilizarInputNumber(erros.anos_experiência_pesquisa, usuárioLogado.cor_tema)} />
                    <MostrarMensagemErro mensagem={erros.anos_experiência_pesquisa} />
                </div>
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Área de Formação*:</label>
                    <Dropdown name="área_formação" value={dados.área_formação} options={opçõesÁreaFormação}
                        onChange={alterarEstado} placeholder="-- Selecione --"
                        className={estilizarDropdown(erros.área_formação, usuárioLogado.cor_tema)} />
                    <MostrarMensagemErro mensagem={erros.área_formação} />
                </div>
                <Divider className={estilizarDivider(usuárioLogado.cor_tema)} />
                <div className={estilizarInlineFlex()}>
                    <Button className={estilizarBotãoRetornar()} label="Retornar" onClick={redirecionar} />
                    <Button className={estilizarBotão()} label={labelBotãoSalvar()} onClick={açãoBotãoSalvar} />
                </div>
            </Card>
        </div>
    );
};