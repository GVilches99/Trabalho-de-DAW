import { BaseEntity, Column, Entity, JoinColumn, OneToMany, OneToOne, PrimaryGeneratedColumn }
    from "typeorm";
import Usuário from "./usuário";
import ReservaAla from "./reserva-ala";
export enum Tipo_Hospital {
    PUBLICO = "público",
    PRIVADO = "privado"
};
@Entity("gerente_hospital") 
export default class GerenteHospital extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;
    @Column()
    nome_hospital: string;
    @Column()
    capacidade_leitos: number;
    @Column({ type: "enum", enum: Tipo_Hospital })
    tipo_hospital: Tipo_Hospital;
    @Column()
    especialidade_médica: string;
    @OneToMany(() => ReservaAla, (reserva_ala) => reserva_ala.gerente_hospital)
    reservas_ala: ReservaAla[];
    @OneToOne(() => Usuário, usuário => usuário.gerente_hospital, { onDelete: "CASCADE" })
    @JoinColumn({ name: 'usuário_cpf' }) 
    usuário: Usuário;
}