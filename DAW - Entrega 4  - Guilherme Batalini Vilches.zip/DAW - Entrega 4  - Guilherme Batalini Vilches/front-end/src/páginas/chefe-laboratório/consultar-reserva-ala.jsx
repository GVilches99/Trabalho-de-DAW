import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Checkbox } from "primereact/checkbox";
import { Divider } from "primereact/divider";
import { InputText } from "primereact/inputtext";
import { InputTextarea } from "primereact/inputtextarea";
import ContextoUsuário from "../../contextos/contexto-usuário";
import ContextoChefeLaboratório from "../../contextos/contexto-chefe-laboratório";
import { estilizarBotão, estilizarBotãoRetornar, estilizarCard, estilizarCheckbox,
    estilizarDivCampo, estilizarDivider, estilizarFlex, estilizarInlineFlex, estilizarInputText,
    estilizarInputTextarea, estilizarLabel } from "../../utilitários/estilos";

export default function ConsultarReservaAla() {
    const { usuárioLogado } = useContext(ContextoUsuário);
    const { reservaAlaConsultada, setGerenteHospitalInteressado } = useContext(ContextoChefeLaboratório);
    
    const dados = {
        nome_gerente_hospital: reservaAlaConsultada?.gerente_hospital?.usuário?.nome,
        temporária: reservaAlaConsultada?.temporária,
        justificativa: reservaAlaConsultada?.justificativa,
        titulo_tratamento_experimental: reservaAlaConsultada?.tratamento_experimental.título,
        id_sala: reservaAlaConsultada?.id_sala,
        número_leitos_reservados: reservaAlaConsultada?.número_leitos_reservados,
        data_reserva: reservaAlaConsultada?.data_reserva,
        prioridade: reservaAlaConsultada?.prioridade
    };
    const navegar = useNavigate();

    function retornarPesquisarReservasAla() { 
        navegar("../pesquisar-reservas-ala"); 
    };
    
    function consultarGerenteHospitalInteressado() {
        setGerenteHospitalInteressado(reservaAlaConsultada.gerente_hospital);
        navegar("../consultar-gerente-hospital-interessado");
    };

    return (
        <div className={estilizarFlex()}>
            <Card title="Consultar Reserva de Ala" className={estilizarCard(usuárioLogado.cor_tema)}>
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Gerente de Hospital*:</label>
                    <InputText name="nome_gerente_hospital"
                        className={estilizarInputText(null, 400, usuárioLogado.cor_tema)}
                        value={dados.nome_gerente_hospital} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Tratamento Experimental*:</label>
                    <InputText name="titulo_tratamento_experimental"
                        className={estilizarInputText(null, 400, usuárioLogado.cor_tema)}
                        value={dados.titulo_tratamento_experimental} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>ID da Sala*:</label>
                    <InputText name="id_sala"
                        className={estilizarInputText(null, 200, usuárioLogado.cor_tema)}
                        value={dados.id_sala} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Leitos Reservados*:</label>
                    <InputText name="número_leitos_reservados"
                        className={estilizarInputText(null, 200, usuárioLogado.cor_tema)}
                        value={dados.número_leitos_reservados} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Data da Reserva*:</label>
                    <InputText name="data_reserva" type="date" 
                        className={estilizarInputText(null, 200, usuárioLogado.cor_tema)}
                        value={dados.data_reserva} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Prioridade*:</label>
                    <InputText name="prioridade"
                        className={estilizarInputText(null, 200, usuárioLogado.cor_tema)}
                        value={dados.prioridade} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Temporária*:</label>
                    <Checkbox name="temporária" checked={dados.temporária}
                        className={estilizarCheckbox()} autoResize disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Justificativa*:</label>
                    <InputTextarea name="justificativa"
                        className={estilizarInputTextarea(null, usuárioLogado.cor_tema)}
                        value={dados.justificativa} disabled />
                </div>
                
                <Divider className={estilizarDivider()} />
                <div className={estilizarInlineFlex()}>
                    <Button className={estilizarBotãoRetornar()} label="Retornar"
                        onClick={retornarPesquisarReservasAla} />
                    <Button className={estilizarBotão()} label="Gerente de Hospital" onClick={consultarGerenteHospitalInteressado} />
                </div>
            </Card>
        </div>
    );
}