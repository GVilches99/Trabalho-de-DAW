import { BrowserRouter, Route, Routes } from "react-router-dom";
import { ProvedorUsuário } from "../contextos/contexto-usuário";
import RotasUsuárioLogado from "./rotas-usuário-logado";
import LogarUsuário from "../páginas/usuário/logar-usuário";
import CadastrarUsuário from "../páginas/usuário/cadastrar-usuário";
import RecuperarAcesso from "../páginas/usuário/recuperar-acesso";
import PáginaInicial from "../páginas/usuário/página-inicial";
import CadastrarChefeLaboratório from "../páginas/chefe-laboratório/cadastrar-chefe-laboratório.jsx";
import CadastrarGerenteHospital from "../páginas/gerente-hospital/cadastrar-gerente-hospital.jsx";

// Importações do Tutorial 3
import { ProvedorChefeLaboratório } from "../contextos/contexto-chefe-laboratório";
import { ProvedorGerenteHospital } from "../contextos/contexto-gerente-hospital";
import RotasChefeLaboratório from "./rotas-chefe-laboratório";
import RotasGerenteHospital from "./rotas-gerente-hospital";
import AdministrarTratamentosExperimentais from "../páginas/chefe-laboratório/administrar-tratamentos-experimentais.jsx";
import CadastrarTratamentoExperimental from "../páginas/chefe-laboratório/cadastrar-tratamento-experimental.jsx";
import AdministrarReservasAla from "../páginas/gerente-hospital/administrar-reservas-ala.jsx";
import CadastrarReservaAla from "../páginas/gerente-hospital/cadastrar-reserva-ala.jsx";
import PesquisarTratamentosExperimentais from "../páginas/gerente-hospital/pesquisar-tratamentos-experimentais.jsx";
import ConsultarTratamentoExperimental from "../páginas/gerente-hospital/consultar-tratamento-experimental.jsx";

export default function RotasAplicação() {
    return (
        <BrowserRouter>
            <ProvedorUsuário>
                <Routes>
                    {/* Rotas públicas */}
                    <Route element={<LogarUsuário />} path="/" />
                    <Route element={<CadastrarUsuário />} path="/criar-usuario" />
                    <Route element={<RecuperarAcesso />} path="/recuperar-acesso" />
                    
                    {/* Rotas protegidas (só para usuários logados) */}
                    <Route element={<RotasUsuárioLogado />}>
                        <Route element={<PáginaInicial />} path="/pagina-inicial" />
                        <Route element={<CadastrarUsuário />} path="/atualizar-usuario" />

                        {/* Rotas do Chefe de Laboratório (Proponente) */}
                        <Route element={<ProvedorChefeLaboratório><RotasChefeLaboratório /></ProvedorChefeLaboratório>}>
                            <Route element={<CadastrarChefeLaboratório />} path="cadastrar-chefe-laboratório" />
                            <Route element={<AdministrarTratamentosExperimentais />} path="administrar-tratamentos-experimentais" />
                            <Route element={<CadastrarTratamentoExperimental />} path="cadastrar-tratamento-experimental" />
                        </Route>

                        {/* Rotas do Gerente de Hospital (Interessado) */}
                        <Route element={<ProvedorGerenteHospital><RotasGerenteHospital /></ProvedorGerenteHospital>}>
                            <Route element={<CadastrarGerenteHospital />} path="cadastrar-gerente-hospital" />
                            <Route element={<AdministrarReservasAla />} path="administrar-reservas-ala" />
                            <Route element={<CadastrarReservaAla />} path="cadastrar-reserva-ala" />
                            <Route element={<PesquisarTratamentosExperimentais />} path="pesquisar-tratamentos-experimentais" />
                            <Route element={<ConsultarTratamentoExperimental />} path="consultar-tratamento-experimental" />
                        </Route>
                    </Route>
                </Routes>
            </ProvedorUsuário>
        </BrowserRouter>
    );
};