export default function formatarPerfil(perfil) {
    switch (perfil) {
        case "chefe_laboratório": return "ChefeLaboratório";
        case "gerente_hospital": return "GerenteHospital";
        default: return;
    }
};