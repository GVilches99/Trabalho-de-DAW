 import { Router } from "express";
 import verificarToken from "../middlewares/verificar-token";
 import verificarPerfilGerenteHospital from "../middlewares/verificar-perfil-gerente-hospital";
 import ServiçosGerenteHospital from "../serviços/serviços-gerente-hospital";
 const RotasGerenteHospital = Router();
 export default RotasGerenteHospital;
 RotasGerenteHospital.post("/", ServiçosGerenteHospital.cadastrarGerenteHospital);
 RotasGerenteHospital.patch("/", verificarToken, verificarPerfilGerenteHospital, ServiçosGerenteHospital.atualizarGerenteHospital);
 RotasGerenteHospital.get("/:cpf", verificarToken, verificarPerfilGerenteHospital, ServiçosGerenteHospital.buscarGerenteHospital);