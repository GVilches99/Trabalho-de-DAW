import md5 from "md5";
import { getManager } from "typeorm";
import Usuário, { Status } from "../entidades/usuário";
import GerenteHospital from '../entidades/gerente-hospital';
import ServiçosUsuário from "./serviços-usuário";
import TratamentoExperimental from "../entidades/tratamento-experimental";
import ReservaAla, { PrioridadeReserva } from "../entidades/reserva-ala";

export default class ServiçosGerenteHospital {
    constructor() { }

    // --- Funções da Entrega 2 (usando getManager) ---
    static async cadastrarGerenteHospital(request, response) {
        try {
            const { usuário_info, nome_hospital, capacidade_leitos, tipo_hospital, especialidade_médica } = request.body;
            const { usuário, token } = await ServiçosUsuário.cadastrarUsuário(usuário_info);
            const entityManager = getManager();

            await entityManager.transaction(async (transactionManager) => {
                await transactionManager.save(usuário);
                const gerente_hospital = GerenteHospital.create({ usuário, nome_hospital, capacidade_leitos, tipo_hospital, especialidade_médica });
                await transactionManager.save(gerente_hospital);
                await transactionManager.update(Usuário, usuário.cpf, { status: Status.ATIVO });
                return response.json({ status: Status.ATIVO, token });
            });
        } catch (error) { 
            return response.status(500).json({ erro: error.message }); 
        }
    };

    static async atualizarGerenteHospital(request, response) {
        try {
            const { cpf, nome_hospital, capacidade_leitos, tipo_hospital, especialidade_médica } = request.body;
            const cpf_encriptado = md5(cpf);
            await GerenteHospital.update({ usuário: { cpf: cpf_encriptado } }, { nome_hospital, capacidade_leitos, tipo_hospital, especialidade_médica });
            return response.json();
        } catch (error) { 
            return response.status(500).json({ erro: "Erro no BD ao atualizar Gerente de Hospital" }); 
        }
    };

    static async buscarGerenteHospital(request, response) {
        try {
            const cpf_encriptado = md5(request.params.cpf);
            const gerente_hospital = await GerenteHospital.findOne({ 
                where: { usuário: cpf_encriptado },
                relations: ["usuário"] 
            });

            if (!gerente_hospital) return response.status(404).json({ erro: "Gerente de Hospital não encontrado." });
            return response.json({ 
                nome: gerente_hospital.usuário.nome, 
                email: gerente_hospital.usuário.email,
                nome_hospital: gerente_hospital.nome_hospital,
                capacidade_leitos: gerente_hospital.capacidade_leitos,
                tipo_hospital: gerente_hospital.tipo_hospital,
                especialidade_médica: gerente_hospital.especialidade_médica
            });
        } catch (error) { 
            return response.status(500).json({ erro: "Erro no BD ao buscar Gerente de Hospital" }); 
        }
    };

    // --- Funções da Entrega 3 (usando .create().save()) ---

    static async cadastrarReservaAla(request, response) {
        try {
            const { id_tratamento_experimental, temporária, justificativa, prioridade, 
                    id_sala, número_leitos_reservados, data_reserva, cpf } = request.body;
            
            const cpf_encriptado = md5(cpf);
            
            const gerente_hospital = await GerenteHospital.findOne({ where: { usuário: { cpf: cpf_encriptado } } });
            const tratamento_experimental = await TratamentoExperimental.findOne(id_tratamento_experimental);

            const reservas_existentes = await ReservaAla.find({ where: { gerente_hospital, tratamento_experimental } });
            if (reservas_existentes.length > 0) {
                return response.status(404).json({ erro: "O Gerente de Hospital já cadastrou reserva para este Tratamento Experimental." });
            }

            await ReservaAla.create({ 
                id_sala,
                número_leitos_reservados,
                data_reserva,
                temporária, 
                justificativa, 
                prioridade, 
                gerente_hospital, 
                tratamento_experimental 
            }).save();
            
            return response.json();
        } catch (error) { return response.status(500).json({ erro: "Erro no BD ao cadastrar Reserva de Ala" }); }
    };

    static async removerReservaAla(request, response) {
        try {
            const id = request.params.id;
            await ReservaAla.delete(id);
            return response.json();
        } catch (error) { return response.status(500).json({ erro: "Erro no BD ao remover Reserva de Ala" }); }
    };

    static async buscarReservasAlaGerenteHospital(request, response) {
        try {
            const cpf_encriptado = md5(request.params.cpf);
            const reservas_ala = await ReservaAla.find({ 
                where: { gerente_hospital: { usuário: { cpf: cpf_encriptado } } },
                relations: [
                    "gerente_hospital", 
                    "gerente_hospital.usuário", 
                    "tratamento_experimental", 
                    "tratamento_experimental.chefe_laboratório",
                    "tratamento_experimental.chefe_laboratório.usuário"
                ] 
            });
            return response.json(reservas_ala);
        } catch (error) { 
            return response.status(500).json({ erro: "Erro no BD ao buscar Reservas de Ala do Gerente de Hospital" }); 
        }
    };

    static async buscarTratamentosExperimentais(request, response) {
        try {
            const tratamentos_experimentais = await TratamentoExperimental.find({ 
                relations: ["chefe_laboratório", "chefe_laboratório.usuário"] 
            });
            return response.json(tratamentos_experimentais);
        } catch (error) { return response.status(500).json({ erro: "Erro no BD ao buscar Tratamentos Experimentais" }); }
    };
}