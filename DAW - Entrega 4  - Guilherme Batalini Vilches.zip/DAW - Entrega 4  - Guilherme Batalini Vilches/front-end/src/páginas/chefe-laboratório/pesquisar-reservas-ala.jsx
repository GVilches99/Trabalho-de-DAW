import { useContext, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Divider } from "primereact/divider";
import { Dropdown } from "primereact/dropdown";
import { Toast } from "primereact/toast";
import { TriStateCheckbox } from "primereact/tristatecheckbox";
import ContextoUsuário from "../../contextos/contexto-usuário";
import ContextoChefeLaboratório from "../../contextos/contexto-chefe-laboratório";
import mostrarToast from "../../utilitários/mostrar-toast";
import { serviçoBuscarReservasAlaTratamento } from "../../serviços/serviços-chefe-laboratório";
import { 
    TAMANHOS, estilizarBotãoRetornar, estilizarBotãoTabela, estilizarCard,
    estilizarColumnHeader, estilizarColunaConsultar, estilizarDataTable, estilizarDataTablePaginator,
    estilizarDivider, estilizarFilterMenu, estilizarFlex, estilizarTriStateCheckbox 
} from "../../utilitários/estilos";

export default function PesquisarReservasAla() {
    const referênciaToast = useRef(null);
    const { usuárioLogado } = useContext(ContextoUsuário);
    const { reservaAlaConsultada, setReservaAlaConsultada,
            tratamentoExperimentalConsultado } = useContext(ContextoChefeLaboratório);
    const [listaReservasAla, setListaReservasAla] = useState([]);
    const navegar = useNavigate();

    const opçõesPrioridade = [
        { label: "Urgente", value: "urgente" },
        { label: "Alta", value: "alta" },
        { label: "Média", value: "media" },
        { label: "Baixa", value: "baixa" }
    ];

    function retornarCadastrarTratamentoExperimental() {
        setReservaAlaConsultada(null);
        navegar("../cadastrar-tratamento-experimental");
    };

    function ConsultarTemplate(reserva_ala) {
        return (
            <Button icon="pi pi-search"
                className={estilizarBotãoTabela(usuárioLogado.cor_tema,
                    reservaAlaConsultada?.id === reserva_ala.id)}
                tooltip="Consultar Reserva de Ala" tooltipOptions={{ position: 'top' }}
                onClick={() => {
                    setReservaAlaConsultada(reserva_ala);
                    navegar("../consultar-reserva-ala");;
                }} />
        );
    };

    function DropdownPrioridadeTemplate(opções) {
        function alterarFiltroDropdown(event) {
            return opções.filterCallback(event.value, opções.index);
        };
        return <Dropdown value={opções.value} options={opçõesPrioridade} placeholder="Selecione"
            onChange={alterarFiltroDropdown} showClear />;
    };

    function BooleanBodyTemplate(reserva_ala) {
        if (reserva_ala.temporária) return "Sim";
        else return "Não";
    };

    function BooleanFilterTemplate(opções) {
        function alterarFiltroTriState(event) { return opções.filterCallback(event.value); };
        return (
            <div>
                <label>Reserva Temporária:</label>
                <TriStateCheckbox
                    className={estilizarTriStateCheckbox(usuárioLogado?.cor_tema)} value={opções.value}
                    onChange={alterarFiltroTriState} />
            </div>
        );
    };

    useEffect(() => {
        let desmontado = false;
        async function buscarReservasAlaTratamento() {
            try {
                const response = await serviçoBuscarReservasAlaTratamento(tratamentoExperimentalConsultado?.id);
                if (!desmontado && response.data) setListaReservasAla(response.data);
            } catch (error) { mostrarToast(referênciaToast, error.response.data.erro, "error"); }
        }
        buscarReservasAlaTratamento();
        return () => desmontado = true;
    }, [tratamentoExperimentalConsultado?.id]);

    return (
        <div className={estilizarFlex()}>
            <Toast ref={referênciaToast} position="bottom-center" />
            <Card title="Reservas de Ala Cadastradas" className={estilizarCard(usuárioLogado.cor_tema)}>
                <DataTable dataKey="id" size="small" paginator rows={TAMANHOS.MAX_LINHAS_TABELA}
                    emptyMessage="Nenhuma reserva de ala encontrada." value={listaReservasAla}
                    responsiveLayout="scroll" breakpoint="490px" removableSort
                    className={estilizarDataTable()}
                    paginatorClassName={estilizarDataTablePaginator(usuárioLogado.cor_tema)}>
                    
                    <Column bodyClassName={estilizarColunaConsultar()} body={ConsultarTemplate}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} />
                    
                    <Column field="gerente_hospital.usuário.nome" header="Gerente de Hospital" filter showFilterOperator={false}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} sortable />
                    
                    <Column field="tratamento_experimental.título" header="Tratamento Experimental" filter showFilterOperator={false}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} sortable />
                    
                    <Column headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)}
                        field="prioridade" header="Prioridade" filter filterMatchMode="equals"
                        filterElement={DropdownPrioridadeTemplate} showClearButton={false}
                        showFilterOperator={false} showFilterMatchModes={false}
                        filterMenuClassName={estilizarFilterMenu()} showFilterMenuOptions={false} sortable />
                    
                    <Column field="temporária" header="Temporária" dataType="boolean" filter
                        showFilterOperator={false} body={BooleanBodyTemplate}
                        filterElement={BooleanFilterTemplate} filterMatchMode="equals" showClearButton={false}
                        showAddButton={false} filterMenuClassName={estilizarFilterMenu()}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} sortable />
                </DataTable>
                
                <Divider className={estilizarDivider()} />
                <Button className={estilizarBotãoRetornar()} label="Retornar"
                    onClick={retornarCadastrarTratamentoExperimental} />
            </Card>
        </div>
    );
}