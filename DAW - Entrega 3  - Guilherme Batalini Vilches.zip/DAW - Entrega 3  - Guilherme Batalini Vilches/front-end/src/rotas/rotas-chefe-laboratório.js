import { useContext } from "react";
import { Navigate, Outlet } from "react-router-dom";
import ContextoUsuário from "../contextos/contexto-usuário";

export default function RotasChefeLaboratório() {
    const { usuárioLogado } = useContext(ContextoUsuário);
    if (usuárioLogado.perfil === "chefe_laboratório") return <Outlet />
    else return <Navigate to="/" />;
}