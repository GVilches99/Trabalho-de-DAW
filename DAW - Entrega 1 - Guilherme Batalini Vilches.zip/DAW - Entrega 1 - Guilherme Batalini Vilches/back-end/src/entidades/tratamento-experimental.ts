import { BaseEntity, Column, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import ChefeLaboratório from "./chefe-laboratório";
import ReservaAla from "./reserva-ala";
export enum Tipo_Câncer_Alvo {
    PULMAO = "pulmão",
    MAMA = "mama",
    PROSTATA = "próstata",
    LEUCEMIA = "leucemia",
    PELE = "pele"
}
export enum Fase_Pesquisa {
    PRE_CLINICA = "pré_clínica",
    FASE_1 = "fase_1",
    FASE_2 = "fase_2",
    FASE_3 = "fase_3"
}
export enum Resultado_Esperado {
    REMISSÃO_COMPLETA = "remissão_completa",
    REDUÇÃO_TUMOR = "redução_tumor",
    AUMENTO_SOBREVIDA = "aumento_sobrevida"
}
@Entity("tratamento_experimental") 
export default class TratamentoExperimental extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;
    @Column()
    título: string;
    @Column({ type: "enum", enum: Tipo_Câncer_Alvo })
    tipo_câncer_alvo: Tipo_Câncer_Alvo;
    @Column({ type: "enum", enum: Fase_Pesquisa })
    fase_pesquisa: Fase_Pesquisa;
    @Column({ type: "date" })
    data_inicio_prevista: Date;
    @Column()
    descrição: string;
    @Column()
    necessita_equipamento_especial: boolean;
    @Column({ type: "enum", enum: Resultado_Esperado })
    resultado_esperado: Resultado_Esperado;
    @Column()
    alto_risco: boolean;
    @ManyToOne(() => ChefeLaboratório, (chefe_laboratório) => chefe_laboratório.tratamentos_experimentais, { onDelete: "CASCADE" })
    @JoinColumn({ name: 'chefe_laboratório_id' }) 
    chefe_laboratório: ChefeLaboratório;
    @OneToMany(() => ReservaAla, (reserva_ala) => reserva_ala.tratamento_experimental)
    reservas_ala: ReservaAla[];
}