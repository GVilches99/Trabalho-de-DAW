import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import ContextoUsuário from "../../contextos/contexto-usuário";
import {
    estilizarBotão, estilizarBotãoRemover, estilizarDivCampo, estilizarInlineFlex,
    estilizarLabel, estilizarModal
} from "../../utilitários/estilos";
export default function ModalConfirmaçãoUsuário() {
    const { setUsuárioLogado, confirmaçãoUsuário, setConfirmaçãoUsuário, setMostrarModalConfirmação } = useContext(ContextoUsuário);
    const navegar = useNavigate();
    const dados = {
        cpf: confirmaçãoUsuário?.cpf,
        perfil: confirmaçãoUsuário?.perfil,
        nome: confirmaçãoUsuário?.nome,
        email: confirmaçãoUsuário?.email,
        senha: confirmaçãoUsuário?.senha,
        questão: confirmaçãoUsuário?.questão,
        resposta: confirmaçãoUsuário?.resposta,
        cor_tema: confirmaçãoUsuário?.cor_tema
    };
    function exibirPerfilFormatado() {
        switch (dados.perfil) {
            case "chefe_laboratório": return "Chefe de Laboratório";
            case "gerente_hospital": return "Gerente de Hospital";
            default: return "";
        }
    }
    function finalizarCadastro() {
        setUsuárioLogado({ ...dados, cadastrado: false });
        setMostrarModalConfirmação(false);
        if (dados.perfil === "chefe_laboratório") {
            navegar("../cadastrar-chefe-laboratório");
        }
    }
    function executarOperação() {
        if (confirmaçãoUsuário.operação === "salvar") {
            finalizarCadastro();
        }
    }
    function ocultar() {
        setConfirmaçãoUsuário({});
        setMostrarModalConfirmação(false);
    }
    return (
        <div className={estilizarModal()}>
            <div className={estilizarDivCampo()}>
                <label className={estilizarLabel(confirmaçãoUsuário?.cor_tema)}>Tipo de Perfil:</label>
                <label>{exibirPerfilFormatado()}</label>
            </div>
            <div className={estilizarDivCampo()}>
                <label className={estilizarLabel(confirmaçãoUsuário?.cor_tema)}>CPF -- nome de usuário:</label>
                <label>{dados.cpf}</label>
            </div>
            <div className={estilizarDivCampo()}>
                <label className={estilizarLabel(confirmaçãoUsuário?.cor_tema)}>Nome Completo:</label>
                <label>{dados.nome}</label>
            </div>
            <div className={estilizarDivCampo()}>
                <label className={estilizarLabel(confirmaçãoUsuário?.cor_tema)}>Email:</label>
                <label>{dados.email}</label>
            </div>
            <div className={estilizarDivCampo()}>
                <label className={estilizarLabel(confirmaçãoUsuário?.cor_tema)}>Questão de Segurança:</label>
                <label>{dados.questão}</label>
            </div>
            <div className={estilizarDivCampo()}>
                <label className={estilizarLabel(confirmaçãoUsuário?.cor_tema)}>Resposta:</label>
                <label>{dados.resposta}</label>
            </div>
            <div className={estilizarInlineFlex()}>
                <Button label="Salvar" onClick={executarOperação}
                    className={estilizarBotão(confirmaçãoUsuário?.cor_tema)} />
                <Button label="Corrigir" onClick={ocultar}
                    className={estilizarBotãoRemover(confirmaçãoUsuário?.cor_tema)} />
            </div>
        </div>
    );
}