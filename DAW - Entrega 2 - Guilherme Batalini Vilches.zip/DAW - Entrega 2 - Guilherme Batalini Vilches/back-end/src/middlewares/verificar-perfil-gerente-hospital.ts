 import { Perfil } from '../entidades/usuário';
 export default function verificarPerfilGerenteHospital(request, response, next) {
 if (request.perfil === Perfil.GERENTE_HOSPITAL) return next();
 else return response.status(401).json({ erro: "Acesso não autorizado." });
 };