import servidor from "./servidor";
export function serviçoCadastrarChefeLaboratório(chefe_laboratório) {
    return servidor.post("/chefes-laboratorio", chefe_laboratório); 
};
export function serviçoBuscarChefeLaboratório(cpf) { 
    return servidor.get(`/chefes-laboratorio/${cpf}`); 
};