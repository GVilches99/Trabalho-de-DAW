import { useContext, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Divider } from "primereact/divider";
import { Dropdown } from "primereact/dropdown";
import { TriStateCheckbox } from "primereact/tristatecheckbox";
import ContextoChefeLaboratório from "../../contextos/contexto-chefe-laboratório";
import ContextoUsuário from "../../contextos/contexto-usuário";
import { serviçoBuscarTratamentosExperimentaisChefeLaboratório } from "../../serviços/serviços-chefe-laboratório";
import mostrarToast from "../../utilitários/mostrar-toast";
import {
    TAMANHOS, estilizarBotão, estilizarBotãoRetornar, estilizarBotãoTabela, estilizarCard,
    estilizarColunaConsultar, estilizarColumnHeader, estilizarDataTable, estilizarDataTablePaginator,
    estilizarDivider, estilizarFilterMenu, estilizarFlex, estilizarTriStateCheckbox
} from "../../utilitários/estilos";

export default function AdministrarTratamentosExperimentais() {
    const referênciaToast = useRef(null);
    const { usuárioLogado } = useContext(ContextoUsuário);
    const { tratamentoExperimentalConsultado, setTratamentoExperimentalConsultado } = useContext(ContextoChefeLaboratório);
    const [listaTratamentosExperimentais, setListaTratamentosExperimentais] = useState([]);
    const navegar = useNavigate();

    const opçõesTipoCâncerAlvo = [
        { label: "Pulmão", value: "pulmão" },
        { label: "Mama", value: "mama" },
        { label: "Próstata", value: "próstata" },
        { label: "Leucemia", value: "leucemia" },
        { label: "Pele", value: "pele" }
    ];

    const opçõesFasePesquisa = [
        { label: "Pré-clínica", value: "pré_clínica" },
        { label: "Fase 1", value: "fase_1" },
        { label: "Fase 2", value: "fase_2" },
        { label: "Fase 3", value: "fase_3" }
    ];

    function retornarPáginaInicial() { navegar("/pagina-inicial"); };

    function adicionarTratamentoExperimental() {
        setTratamentoExperimentalConsultado(null);
        navegar("../cadastrar-tratamento-experimental");
    };

    function ConsultarTemplate(tratamento_experimental) {
        function consultar() {
            setTratamentoExperimentalConsultado(tratamento_experimental);
            navegar("../cadastrar-tratamento-experimental");
        };
        return (
            <Button icon="pi pi-search"
                className={estilizarBotãoTabela(usuárioLogado.cor_tema,
                    tratamentoExperimentalConsultado?.id === tratamento_experimental.id)}
                tooltip="Consultar Tratamento Experimental" tooltipOptions={{ position: 'top' }} onClick={consultar} />
        );
    };

    function DropdownTipoCâncerTemplate(opções) {
        function alterarFiltroDropdown(event) {
            return opções.filterCallback(event.value, opções.index);
        };
        return <Dropdown value={opções.value} options={opçõesTipoCâncerAlvo} placeholder="Selecione"
            onChange={alterarFiltroDropdown} showClear />;
    };

    function DropdownFasePesquisaTemplate(opções) {
        function alterarFiltroDropdown(event) {
            return opções.filterCallback(event.value, opções.index);
        };
        return <Dropdown value={opções.value} options={opçõesFasePesquisa} placeholder="Selecione"
            onChange={alterarFiltroDropdown} showClear />;
    };

    function BooleanBodyTemplate(tratamento_experimental) {
        if (tratamento_experimental.necessita_equipamento_especial) return "Sim";
        else return "Não";
    };

    function BooleanFilterTemplate(opções) {
        function alterarFiltroTriState(event) { return opções.filterCallback(event.value); };
        return (
            <div>
                <label>Necessita equipamento especial:</label>
                <TriStateCheckbox
                    className={estilizarTriStateCheckbox(usuárioLogado?.cor_tema)} value={opções.value}
                    onChange={alterarFiltroTriState} />
            </div>
        );
    };

    useEffect(() => {
        let desmontado = false;
        async function buscarTratamentosExperimentaisChefeLaboratório() {
            try {
                const response = await serviçoBuscarTratamentosExperimentaisChefeLaboratório(usuárioLogado.cpf);
                if (!desmontado && response.data) {
                    setListaTratamentosExperimentais(response.data);
                }
            } catch (error) {
                const erro = error.response.data.erro;
                if (erro) mostrarToast(referênciaToast, erro, "error");
            }
        }
        buscarTratamentosExperimentaisChefeLaboratório();
        return () => desmontado = true;
    }, [usuárioLogado.cpf]);

    return (
        <div className={estilizarFlex()}>
            <Card title="Administrar Tratamentos Experimentais" className={estilizarCard(usuárioLogado.cor_tema)}>
                <DataTable dataKey="id" size="small" paginator rows={TAMANHOS.MAX_LINHAS_TABELA}
                    emptyMessage="Nenhum tratamento experimental encontrado."
                    value={listaTratamentosExperimentais}
                    responsiveLayout="scroll" breakpoint="490px" removableSort
                    className={estilizarDataTable()}
                    paginatorClassName={estilizarDataTablePaginator(usuárioLogado.cor_tema)}>
                    
                    <Column bodyClassName={estilizarColunaConsultar()} body={ConsultarTemplate}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} />
                    
                    <Column field="título" header="Título" filter showFilterOperator={false}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} sortable />
                    
                    <Column headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)}
                        field="tipo_câncer_alvo" header="Tipo de Câncer Alvo" filter filterMatchMode="equals"
                        filterElement={DropdownTipoCâncerTemplate} showClearButton={false}
                        showFilterOperator={false} showFilterMatchModes={false}
                        filterMenuClassName={estilizarFilterMenu()} showFilterMenuOptions={false} sortable />
                    
                    <Column headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)}
                        field="fase_pesquisa" header="Fase da Pesquisa" filter filterMatchMode="equals"
                        filterElement={DropdownFasePesquisaTemplate} showClearButton={false}
                        showFilterOperator={false} showFilterMatchModes={false}
                        filterMenuClassName={estilizarFilterMenu()} showFilterMenuOptions={false} sortable />
                    
                    <Column field="necessita_equipamento_especial" header="Necessita Equipamento Especial" filter
                        showFilterOperator={false}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} sortable
                        filterMatchMode="equals" filterElement={BooleanFilterTemplate}
                        body={BooleanBodyTemplate} showClearButton={false} showAddButton={false}
                        filterMenuClassName={estilizarFilterMenu()} dataType="boolean" />
                </DataTable>
                
                <Divider className={estilizarDivider()} />
                <Button className={estilizarBotãoRetornar()} label="Retornar"
                    onClick={retornarPáginaInicial} />
                <Button className={estilizarBotão()} label="Adicionar" onClick={adicionarTratamentoExperimental} />
            </Card>
        </div>
    );
}