import React from 'react';
import ReactDOM from 'react-dom/client'; // 1. MUDANÇA AQUI (importa de 'react-dom/client')

// Seus imports de CSS (mantendo os que já devem existir)
import 'primereact/resources/themes/saga-blue/theme.css'; // (ou o tema que você usa)
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import 'primeflex/primeflex.css';
import './global.css';

import RotasAplicação from './rotas/rotas-aplicação'; // Seu componente principal

// 2. MUDANÇA AQUI (Substituindo o 'ReactDOM.render')
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <RotasAplicação />
  </React.StrictMode>
);