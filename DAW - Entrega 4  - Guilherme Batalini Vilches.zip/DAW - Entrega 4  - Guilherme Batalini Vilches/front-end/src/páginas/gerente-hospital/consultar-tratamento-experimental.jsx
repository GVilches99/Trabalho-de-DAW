import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Checkbox } from "primereact/checkbox";
import { Divider } from "primereact/divider";
import { InputText } from "primereact/inputtext";
import { InputTextarea } from "primereact/inputtextarea";
import ContextoUsuário from "../../contextos/contexto-usuário";
import ContextoGerenteHospital from "../../contextos/contexto-gerente-hospital";
import { estilizarBotão,
    estilizarBotãoRetornar, estilizarCard, estilizarCheckbox, estilizarDivCampo,
    estilizarDivider, estilizarFlex, estilizarInlineFlex, estilizarInputText, 
    estilizarInputTextarea, estilizarLabel
} from "../../utilitários/estilos";

export default function ConsultarTratamentoExperimental() {
    const { usuárioLogado } = useContext(ContextoUsuário);
    const { tratamentoExperimentalConsultado, tratamentoExperimentalDaReserva,
        setChefeLaboratorioProponente } 
    = useContext(ContextoGerenteHospital);
    
    const dados = {
        nome_chefe_laboratório: tratamentoExperimentalConsultado?.chefe_laboratório?.usuário?.nome 
            || tratamentoExperimentalDaReserva?.chefe_laboratório?.usuário?.nome,
        título: tratamentoExperimentalConsultado?.título || tratamentoExperimentalDaReserva?.título,
        tipo_câncer_alvo: tratamentoExperimentalConsultado?.tipo_câncer_alvo || tratamentoExperimentalDaReserva?.tipo_câncer_alvo,
        fase_pesquisa: tratamentoExperimentalConsultado?.fase_pesquisa || tratamentoExperimentalDaReserva?.fase_pesquisa,
        data_inicio_prevista: tratamentoExperimentalConsultado?.data_inicio_prevista || tratamentoExperimentalDaReserva?.data_inicio_prevista,
        descrição: tratamentoExperimentalConsultado?.descrição || tratamentoExperimentalDaReserva?.descrição,
        necessita_equipamento_especial: tratamentoExperimentalConsultado?.necessita_equipamento_especial 
            || tratamentoExperimentalDaReserva?.necessita_equipamento_especial,
        alto_risco: tratamentoExperimentalConsultado?.alto_risco || tratamentoExperimentalDaReserva?.alto_risco,
        resultado_esperado: tratamentoExperimentalConsultado?.resultado_esperado || tratamentoExperimentalDaReserva?.resultado_esperado
    };

    const navegar = useNavigate();

    function consultarChefeLaboratorioProponente() {
    if (tratamentoExperimentalConsultado) setChefeLaboratorioProponente(tratamentoExperimentalConsultado.chefe_laboratório);
    else setChefeLaboratorioProponente(tratamentoExperimentalDaReserva.chefe_laboratório);
    navegar("../consultar-chefe-laboratorio-proponente");
};


    function retornar() {
        if (tratamentoExperimentalConsultado) navegar("../pesquisar-tratamentos-experimentais");
        else if (tratamentoExperimentalDaReserva) navegar("../cadastrar-reserva-ala");
    };

    return (
        <div className={estilizarFlex()}>
            <Card title="Consultar Tratamento Experimental" className={estilizarCard(usuárioLogado.cor_tema)}>
                
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Chefe de Laboratório*:</label>
                    <InputText name="nome_chefe_laboratório"
                        className={estilizarInputText(null, 400, usuárioLogado.cor_tema)}
                        value={dados.nome_chefe_laboratório} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Título*:</label>
                    <InputText name="título" 
                        className={estilizarInputText(null, 400, usuárioLogado.cor_tema)}
                        value={dados.título} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Tipo de Câncer Alvo*:</label>
                    <InputText name="tipo_câncer_alvo"
                        className={estilizarInputText(null, 200, usuárioLogado.cor_tema)}
                        value={dados.tipo_câncer_alvo} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Fase da Pesquisa*:</label>
                    <InputText name="fase_pesquisa"
                        className={estilizarInputText(null, 350, usuárioLogado.cor_tema)}
                        value={dados.fase_pesquisa} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Data de Início Prevista*:</label>
                    <InputText name="data_inicio_prevista" type="date" value={dados.data_inicio_prevista}
                        className={estilizarInputText(null, 200, usuárioLogado.cor_tema)}
                        disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Descrição*:</label>
                    <InputTextarea name="descrição" value={dados.descrição}
                        className={estilizarInputTextarea(null, usuárioLogado.cor_tema)} autoResize disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Necessita Equipamento Especial:</label>
                    <Checkbox name="necessita_equipamento_especial" checked={dados.necessita_equipamento_especial}
                        className={estilizarCheckbox(null)} autoResize disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Alto Risco:</label>
                    <Checkbox name="alto_risco" checked={dados.alto_risco}
                        className={estilizarCheckbox(null)} autoResize disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Resultado Esperado*:</label>
                    <InputText name="resultado_esperado"
                        className={estilizarInputText(null, 200, usuárioLogado.cor_tema)}
                        value={dados.resultado_esperado} autoResize disabled />
                </div>
                
                <Divider className={estilizarDivider()} />
                <div className={estilizarInlineFlex()}>
                    <Button className={estilizarBotãoRetornar()} label="Retornar" onClick={retornar} />
                    <Button className={estilizarBotão()} label="Chefe de Laboratório" onClick={consultarChefeLaboratorioProponente} />
                </div>
            </Card>
        </div>
    );
}