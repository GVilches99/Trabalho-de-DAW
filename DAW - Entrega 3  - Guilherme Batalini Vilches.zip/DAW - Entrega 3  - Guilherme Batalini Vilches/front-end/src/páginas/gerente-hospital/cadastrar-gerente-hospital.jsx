import { useContext, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Divider } from "primereact/divider";
import { Dropdown } from "primereact/dropdown";
import { InputNumber } from "primereact/inputnumber";
import { InputText } from "primereact/inputtext";
import { Toast } from "primereact/toast";
import ContextoUsuário from "../../contextos/contexto-usuário";
import { serviçoCadastrarGerenteHospital, serviçoAtualizarGerenteHospital, serviçoBuscarGerenteHospital }
    from "../../serviços/serviços-gerente-hospital";
import mostrarToast from "../../utilitários/mostrar-toast";
import { MostrarMensagemErro, checarListaVazia, validarCamposObrigatórios }
    from "../../utilitários/validações";
import {
    estilizarBotão, estilizarBotãoRetornar, estilizarCard, estilizarDivCampo,
    estilizarDivider, estilizarDropdown, estilizarFlex, estilizarInlineFlex, estilizarInputNumber,
    estilizarInputText, estilizarLabel
} from "../../utilitários/estilos";

export default function CadastrarGerenteHospital() {
    const referênciaToast = useRef(null);
    const { usuárioLogado, setUsuárioLogado } = useContext(ContextoUsuário);
    const [dados, setDados] = useState({ nome_hospital: "", capacidade_leitos: null, tipo_hospital: "", especialidade_médica: "" });
    const [erros, setErros] = useState({});
    const [cpfExistente, setCpfExistente] = useState(false);
    const navegar = useNavigate();

    const opçõesTipoHospital = [
        { label: "Público", value: "público" },
        { label: "Privado", value: "privado" }
    ];

    function alterarEstado(event) {
        const chave = event.target.name;
        const valor = event.target.value;
        setDados({ ...dados, [chave]: valor });
    };

    function validarCampos() {
        const errosCamposObrigatórios = validarCamposObrigatórios(dados);
        setErros(errosCamposObrigatórios);
        return checarListaVazia(errosCamposObrigatórios);
    };

    function títuloFormulário() {
        if (usuárioLogado?.cadastrado) return "Alterar Gerente de Hospital";
        else return "Cadastrar Gerente de Hospital";
    };

    async function cadastrarGerenteHospital() {
        if (validarCampos()) {
            try {
                const response = await serviçoCadastrarGerenteHospital({ ...dados, usuário_info: usuárioLogado });
                if (response.data) {
                    setUsuárioLogado(usuário => ({
                        ...usuário, status: response.data.status,
                        token: response.data.token
                    }));
                }
                mostrarToast(referênciaToast, "Gerente de Hospital cadastrado com sucesso!", "sucesso");
            } catch (error) {
                setCpfExistente(true);
                mostrarToast(referênciaToast, error.response.data.erro, "erro");
            }
        }
    };
    
    async function atualizarGerenteHospital() {
        if (validarCampos()) {
            try {
                const response = await serviçoAtualizarGerenteHospital({ ...dados, cpf: usuárioLogado.cpf });
                if (response) mostrarToast(referênciaToast, "Gerente de Hospital atualizado com sucesso!", "sucesso");
            } catch (error) {
                mostrarToast(referênciaToast, error.response.data.erro, "erro");
            }
        }
    };
    
    function labelBotãoSalvar() {
        if (usuárioLogado?.cadastrado) return "Alterar";
        else return "Cadastrar";
    };
    
    function açãoBotãoSalvar() {
        if (usuárioLogado?.cadastrado) {
            atualizarGerenteHospital();
        } else {
            cadastrarGerenteHospital();
        }
    };

    function redirecionar() {
        if (cpfExistente) {
            setUsuárioLogado(null);
            navegar("/criar-usuario");
        } else {
            setUsuárioLogado(usuárioLogado => ({ ...usuárioLogado, cadastrado: true }));
            navegar("/pagina-inicial");
        }
    };
    
    useEffect(() => {
        let desmontado = false;
        async function buscarDadosGerenteHospital() {
            try {
                const response = await serviçoBuscarGerenteHospital(usuárioLogado.cpf);
                if (!desmontado && response.data) {
                    setDados(response.data);
                }
            } catch (error) {
                const erro = error.response.data.erro;
                if (erro) mostrarToast(referênciaToast, erro, "erro");
            }
        }
        if (usuárioLogado?.cadastrado) {
            buscarDadosGerenteHospital();
        }
        return () => desmontado = true;
    }, [usuárioLogado?.cadastrado, usuárioLogado.cpf]);
    
    return (
        <div className={estilizarFlex()}>
            <Toast ref={referênciaToast} onHide={redirecionar} position="bottom-center" />
            <Card title={títuloFormulário()} className={estilizarCard(usuárioLogado.cor_tema)}>
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Nome do Hospital*:</label>
                    <InputText name="nome_hospital" value={dados.nome_hospital} onChange={alterarEstado}
                        className={estilizarInputText(erros.nome_hospital, 400, usuárioLogado.cor_tema)} />
                    <MostrarMensagemErro mensagem={erros.nome_hospital} />
                </div>
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Capacidade de Leitos*:</label>
                    <InputNumber name="capacidade_leitos" value={dados.capacidade_leitos}
                        onValueChange={(e) => alterarEstado({ target: { name: 'capacidade_leitos', value: e.value } })}
                        mode="decimal" inputClassName={estilizarInputNumber(erros.capacidade_leitos, usuárioLogado.cor_tema)} />
                    <MostrarMensagemErro mensagem={erros.capacidade_leitos} />
                </div>
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Tipo de Hospital*:</label>
                    <Dropdown name="tipo_hospital" value={dados.tipo_hospital} options={opçõesTipoHospital}
                        onChange={alterarEstado} placeholder="-- Selecione --"
                        className={estilizarDropdown(erros.tipo_hospital, usuárioLogado.cor_tema)} />
                    <MostrarMensagemErro mensagem={erros.tipo_hospital} />
                </div>
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Especialidade Médica*:</label>
                    <InputText name="especialidade_médica" value={dados.especialidade_médica} onChange={alterarEstado}
                        className={estilizarInputText(erros.especialidade_médica, 400, usuárioLogado.cor_tema)} />
                    <MostrarMensagemErro mensagem={erros.especialidade_médica} />
                </div>
                <Divider className={estilizarDivider(usuárioLogado.cor_tema)} />
                <div className={estilizarInlineFlex()}>
                    <Button className={estilizarBotãoRetornar()} label="Retornar" onClick={redirecionar} />
                    <Button className={estilizarBotão()} label={labelBotãoSalvar()} onClick={açãoBotãoSalvar} />
                </div>
            </Card>
        </div>
    );
};