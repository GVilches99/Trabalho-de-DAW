import servidor from "./servidor";
 export function serviçoCadastrarGerenteHospital(gerente_hospital) { return servidor.post("/gerentes-hospital", gerente_hospital); };
 export function serviçoAtualizarGerenteHospital(gerente_hospital) { return servidor.patch("/gerentes-hospital", gerente_hospital); };
 export function serviçoBuscarGerenteHospital(cpf) { return servidor.get(`/gerentes-hospital/${cpf}`); };