 import { Router } from "express";
 import verificarToken from "../middlewares/verificar-token";
 import verificarPerfilGerenteHospital from "../middlewares/verificar-perfil-gerente-hospital";
 import ServiçosGerenteHospital from "../serviços/serviços-gerente-hospital";
import verificarErroConteúdoToken from "src/middlewares/verificar-erro-conteúdo-token";
 const RotasGerenteHospital = Router();

 RotasGerenteHospital.post("/reservas-ala", verificarToken, verificarPerfilGerenteHospital,
    ServiçosGerenteHospital.cadastrarReservaAla);

RotasGerenteHospital.delete("/reservas-ala/:id", verificarToken, verificarPerfilGerenteHospital,
    ServiçosGerenteHospital.removerReservaAla);

RotasGerenteHospital.get("/reservas-ala/gerente-hospital/:cpf", verificarToken, verificarPerfilGerenteHospital,
    verificarErroConteúdoToken, ServiçosGerenteHospital.buscarReservasAlaGerenteHospital);

RotasGerenteHospital.get("/reservas-ala/tratamentos-experimentais", verificarToken, verificarPerfilGerenteHospital,
    ServiçosGerenteHospital.buscarTratamentosExperimentais);

 export default RotasGerenteHospital;
 RotasGerenteHospital.post("/", ServiçosGerenteHospital.cadastrarGerenteHospital);
 RotasGerenteHospital.patch("/", verificarToken, verificarPerfilGerenteHospital, ServiçosGerenteHospital.atualizarGerenteHospital);
 RotasGerenteHospital.get("/:cpf", verificarToken, verificarPerfilGerenteHospital, ServiçosGerenteHospital.buscarGerenteHospital);