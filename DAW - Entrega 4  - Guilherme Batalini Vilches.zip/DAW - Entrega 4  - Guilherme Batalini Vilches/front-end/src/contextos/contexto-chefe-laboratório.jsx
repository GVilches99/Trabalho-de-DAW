import { createContext, useState } from "react";

const ContextoChefeLaboratório = createContext();
export default ContextoChefeLaboratório;

export function ProvedorChefeLaboratório({ children }) {
    const [tratamentoExperimentalConsultado, setTratamentoExperimentalConsultado] = useState({});
    const [reservaAlaConsultada, setReservaAlaConsultada] = useState(null);
    const [gerenteHospitalInteressado, setGerenteHospitalInteressado] = useState(null);

    return (
        <ContextoChefeLaboratório.Provider value={{ 
            tratamentoExperimentalConsultado, setTratamentoExperimentalConsultado,
            reservaAlaConsultada, setReservaAlaConsultada,
            gerenteHospitalInteressado, setGerenteHospitalInteressado
        }}>
            {children}
        </ContextoChefeLaboratório.Provider>
    );
}