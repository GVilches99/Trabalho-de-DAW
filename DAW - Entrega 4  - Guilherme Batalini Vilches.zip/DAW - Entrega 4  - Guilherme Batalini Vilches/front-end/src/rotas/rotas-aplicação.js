import { BrowserRouter, Route, Routes } from "react-router-dom";
import { ProvedorUsuário } from "../contextos/contexto-usuário";
import RotasUsuárioLogado from "./rotas-usuário-logado";
import LogarUsuário from "../páginas/usuário/logar-usuário";
import CadastrarUsuário from "../páginas/usuário/cadastrar-usuário";
import RecuperarAcesso from "../páginas/usuário/recuperar-acesso";
import PáginaInicial from "../páginas/usuário/página-inicial";
import CadastrarChefeLaboratório from "../páginas/chefe-laboratório/cadastrar-chefe-laboratório.jsx";
import CadastrarGerenteHospital from "../páginas/gerente-hospital/cadastrar-gerente-hospital.jsx";

import { ProvedorChefeLaboratório } from "../contextos/contexto-chefe-laboratório";
import { ProvedorGerenteHospital } from "../contextos/contexto-gerente-hospital";
import RotasChefeLaboratório from "./rotas-chefe-laboratório";
import RotasGerenteHospital from "./rotas-gerente-hospital";
import AdministrarTratamentosExperimentais from "../páginas/chefe-laboratório/administrar-tratamentos-experimentais.jsx";
import CadastrarTratamentoExperimental from "../páginas/chefe-laboratório/cadastrar-tratamento-experimental.jsx";
import AdministrarReservasAla from "../páginas/gerente-hospital/administrar-reservas-ala.jsx";
import CadastrarReservaAla from "../páginas/gerente-hospital/cadastrar-reserva-ala.jsx";
import PesquisarTratamentosExperimentais from "../páginas/gerente-hospital/pesquisar-tratamentos-experimentais.jsx";
import ConsultarTratamentoExperimental from "../páginas/gerente-hospital/consultar-tratamento-experimental.jsx";

import PesquisarReservasAla from "../páginas/chefe-laboratório/pesquisar-reservas-ala.jsx";
import ConsultarReservaAla from "../páginas/chefe-laboratório/consultar-reserva-ala.jsx";
import ConsultarGerenteHospital from "../páginas/chefe-laboratório/consultar-gerente-hospital.jsx";
import ConsultarChefeLaboratorio from "../páginas/gerente-hospital/consultar-chefe-laboratório.jsx";

export default function RotasAplicação() {
    return (
        <BrowserRouter>
            <ProvedorUsuário>
                <Routes>
                    <Route element={<LogarUsuário />} path="/" />
                    <Route element={<CadastrarUsuário />} path="/criar-usuario" />
                    <Route element={<RecuperarAcesso />} path="/recuperar-acesso" />
                    
                    <Route element={<RotasUsuárioLogado />}>
                        <Route element={<PáginaInicial />} path="/pagina-inicial" />
                        <Route element={<CadastrarUsuário />} path="/atualizar-usuario" />

                        <Route element={<ProvedorChefeLaboratório><RotasChefeLaboratório /></ProvedorChefeLaboratório>}>
                            <Route element={<CadastrarChefeLaboratório />} path="cadastrar-chefe-laboratório" />
                            <Route element={<AdministrarTratamentosExperimentais />} path="administrar-tratamentos-experimentais" />
                            <Route element={<CadastrarTratamentoExperimental />} path="cadastrar-tratamento-experimental" />
                            <Route element={<PesquisarReservasAla />} path="pesquisar-reservas-ala" />
                            <Route element={<ConsultarReservaAla />} path="consultar-reserva-ala" />
                            <Route element={<ConsultarGerenteHospital />} path="consultar-gerente-hospital-interessado" />
                        </Route>

                        <Route element={<ProvedorGerenteHospital><RotasGerenteHospital /></ProvedorGerenteHospital>}>
                            <Route element={<CadastrarGerenteHospital />} path="cadastrar-gerente-hospital" />
                            <Route element={<AdministrarReservasAla />} path="administrar-reservas-ala" />
                            <Route element={<CadastrarReservaAla />} path="cadastrar-reserva-ala" />
                            <Route element={<PesquisarTratamentosExperimentais />} path="pesquisar-tratamentos-experimentais" />
                            <Route element={<ConsultarTratamentoExperimental />} path="consultar-tratamento-experimental" />
                            <Route element={<ConsultarChefeLaboratorio />} path="consultar-chefe-laboratorio-proponente" />
                        </Route>
                    </Route>
                </Routes>
            </ProvedorUsuário>
        </BrowserRouter>
    );
};