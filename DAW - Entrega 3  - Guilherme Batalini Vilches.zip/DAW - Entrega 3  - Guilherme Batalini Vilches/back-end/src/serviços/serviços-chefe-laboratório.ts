import md5 from "md5";
import { getManager } from "typeorm";
import Usuário, { Status } from "../entidades/usuário";
import ChefeLaboratório from "../entidades/chefe-laboratório";
import ServiçosUsuário from "./serviços-usuário";
import TratamentoExperimental, { Tipo_Câncer_Alvo, Fase_Pesquisa, Resultado_Esperado } from "../entidades/tratamento-experimental";

export default class ServiçosChefeLaboratório {
    constructor() { }

    // --- Funções da Entrega 2 (usando getManager) ---
    static async cadastrarChefeLaboratório(request, response) {
        try {
            const { usuário_info, instituição_pesquisa, anos_experiência_pesquisa, área_formação } = request.body;
            const { usuário, token } = await ServiçosUsuário.cadastrarUsuário(usuário_info);
            const entityManager = getManager();
            await entityManager.transaction(async (transactionManager) => {
                await transactionManager.save(usuário);
                const chefe_laboratório = ChefeLaboratório.create({ usuário, instituição_pesquisa, anos_experiência_pesquisa, área_formação });
                await transactionManager.save(chefe_laboratório);
                await transactionManager.update(Usuário, usuário.cpf, { status: Status.ATIVO });
                return response.json({ status: Status.ATIVO, token });
            });
        } catch (error) { return response.status(500).json({ erro: error.message }); }
    };

    static async atualizarChefeLaboratório(request, response) {
        try {
            const { cpf, instituição_pesquisa, anos_experiência_pesquisa, área_formação } = request.body;
            const cpf_encriptado = md5(cpf);
            await ChefeLaboratório.update({ usuário: { cpf: cpf_encriptado } }, { instituição_pesquisa, anos_experiência_pesquisa, área_formação });
            return response.json();
        } catch (error) { return response.status(500).json({ erro: "Erro no BD ao atualizar Chefe de Laboratório" }); }
    };

    static async buscarChefeLaboratório(request, response) {
        try {
            const cpf_encriptado = md5(request.params.cpf);
            const chefe_laboratório = await ChefeLaboratório.findOne({ where: { usuário: cpf_encriptado }, relations: ["usuário"] });
            if (!chefe_laboratório) return response.status(404).json({ erro: "Chefe de Laboratório não encontrado." });
            return response.json({
                nome: chefe_laboratório.usuário.nome,
                email: chefe_laboratório.usuário.email,
                instituição_pesquisa: chefe_laboratório.instituição_pesquisa,
                anos_experiência_pesquisa: chefe_laboratório.anos_experiência_pesquisa,
                área_formação: chefe_laboratório.área_formação
            });
        } catch (error) { return response.status(500).json({ erro: "Erro no BD ao buscar Chefe de Laboratório" }); }
    };

    // --- Funções da Entrega 3 (usando .create().save()) ---

    static async cadastrarTratamentoExperimental(request, response) {
        try {
            const { título, tipo_câncer_alvo, fase_pesquisa, data_inicio_prevista, descrição, 
                    necessita_equipamento_especial, alto_risco, resultado_esperado, cpf } = request.body;
            
            const cpf_encriptado = md5(cpf);
            const chefe_laboratório = await ChefeLaboratório.findOne({ where: { usuário: { cpf: cpf_encriptado } } });
            
            await TratamentoExperimental.create({ 
                título, 
                tipo_câncer_alvo, 
                fase_pesquisa, 
                data_inicio_prevista,
                descrição, 
                necessita_equipamento_especial, 
                alto_risco, 
                resultado_esperado, 
                chefe_laboratório 
            }).save();
            
            return response.json();
        } catch (error) { return response.status(500).json({ erro: "Erro no BD ao cadastrar Tratamento Experimental" }); }
    };

    static async alterarTratamentoExperimental(request, response) {
        try {
            const { id, título, tipo_câncer_alvo, fase_pesquisa, data_inicio_prevista, descrição, 
                    necessita_equipamento_especial, alto_risco, resultado_esperado } = request.body;
            
            await TratamentoExperimental.update(id, { 
                título, 
                tipo_câncer_alvo, 
                fase_pesquisa, 
                data_inicio_prevista,
                descrição, 
                necessita_equipamento_especial, 
                alto_risco, 
                resultado_esperado 
            });
            
            return response.json();
        } catch (error) { return response.status(500).json({ erro: "Erro no BD ao alterar Tratamento Experimental" }); }
    };

    static async removerTratamentoExperimental(request, response) {
        try {
            const id_tratamento_experimental = request.params.id;
            // --- CORREÇÃO AQUI ---
            // Corrigindo o erro de digitação de 'id_tramento_experimental' para 'id_tratamento_experimental'
            const tratamento_experimental = await TratamentoExperimental.findOne(id_tratamento_experimental);
            // --- FIM DA CORREÇÃO ---
            await TratamentoExperimental.remove(tratamento_experimental);
            return response.json();
        } catch (error) { return response.status(500).json({ erro: "Erro no BD ao remover Tratamento Experimental" }); }
    };

    static async buscarTratamentosExperimentaisChefeLaboratório(request, response) {
        try {
            const cpf_encriptado = md5(request.params.cpf);
            const tratamentos_experimentais = await TratamentoExperimental.find({ 
                where: { chefe_laboratório: { usuário: { cpf: cpf_encriptado } } },
                relations: ["chefe_laboratório", "chefe_laboratório.usuário"] 
            });
            return response.json(tratamentos_experimentais);
        } catch (error) { 
            return response.status(500).json({ erro: "Erro no BD ao buscar Tratamentos Experimentais do Chefe de Laboratório" }); 
        }
    };
}