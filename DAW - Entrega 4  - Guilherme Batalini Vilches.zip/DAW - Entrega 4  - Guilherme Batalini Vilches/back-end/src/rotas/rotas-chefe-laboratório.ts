import { Router } from "express";
import verificarToken from "../middlewares/verificar-token";
import verificarPerfilChefeLaboratório from "../middlewares/verificar-perfil-chefe-laboratório";
import ServiçosChefeLaboratório from "../serviços/serviços-chefe-laboratório";
import verificarErroConteúdoToken from "src/middlewares/verificar-erro-conteúdo-token";
const RotasChefeLaboratório = Router();

RotasChefeLaboratório.post("/tratamentos-experimentais", verificarToken, verificarPerfilChefeLaboratório,
    ServiçosChefeLaboratório.cadastrarTratamentoExperimental);

RotasChefeLaboratório.patch("/tratamentos-experimentais", verificarToken, verificarPerfilChefeLaboratório,
    ServiçosChefeLaboratório.alterarTratamentoExperimental);

RotasChefeLaboratório.delete("/tratamentos-experimentais/:id", verificarToken, verificarPerfilChefeLaboratório,
    ServiçosChefeLaboratório.removerTratamentoExperimental);

RotasChefeLaboratório.get("/tratamentos-experimentais/chefe-laboratorio/:cpf", verificarToken, verificarPerfilChefeLaboratório,
    verificarErroConteúdoToken, ServiçosChefeLaboratório.buscarTratamentosExperimentaisChefeLaboratório);
    
export default RotasChefeLaboratório;
RotasChefeLaboratório.post("/", ServiçosChefeLaboratório.cadastrarChefeLaboratório);
RotasChefeLaboratório.get("/:cpf", 
    verificarToken, 
    verificarPerfilChefeLaboratório,
    ServiçosChefeLaboratório.buscarChefeLaboratório
);
 RotasChefeLaboratório.patch("/", verificarToken, verificarPerfilChefeLaboratório, 
   ServiçosChefeLaboratório.atualizarChefeLaboratório);

RotasChefeLaboratório.get("/reservas-ala/:id_tratamento_experimental", verificarToken, verificarPerfilChefeLaboratório,
    ServiçosChefeLaboratório.buscarReservasAlaTratamento);