import { useContext, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Checkbox } from "primereact/checkbox";
import { Divider } from "primereact/divider";
import { Dropdown } from "primereact/dropdown";
import { InputText } from "primereact/inputtext";
import { InputTextarea } from "primereact/inputtextarea";
import { Toast } from "primereact/toast";
import ContextoUsuário from "../../contextos/contexto-usuário";
import ContextoChefeLaboratório from "../../contextos/contexto-chefe-laboratório";
import { 
    serviçoAlterarTratamentoExperimental, 
    serviçoCadastrarTratamentoExperimental, 
    serviçoRemoverTratamentoExperimental 
} from "../../serviços/serviços-chefe-laboratório";
import mostrarToast from "../../utilitários/mostrar-toast";
import { MostrarMensagemErro, checarListaVazia, validarCamposObrigatórios } 
    from "../../utilitários/validações";
import { 
    estilizarBotão, estilizarBotãoRemover, estilizarBotãoRetornar, estilizarCard,
    estilizarCheckbox, estilizarDivCampo, estilizarDivider, estilizarDropdown, estilizarFlex,
    estilizarInlineFlex, estilizarInputText, estilizarInputTextarea, estilizarLabel 
} from "../../utilitários/estilos";

export default function CadastrarTratamentoExperimental() {
    const referênciaToast = useRef(null);
    const { usuárioLogado } = useContext(ContextoUsuário);
    const { tratamentoExperimentalConsultado } = useContext(ContextoChefeLaboratório);
    
    const [dados, setDados] = useState({ 
        título: tratamentoExperimentalConsultado?.título || "",
        tipo_câncer_alvo: tratamentoExperimentalConsultado?.tipo_câncer_alvo || "",
        fase_pesquisa: tratamentoExperimentalConsultado?.fase_pesquisa || "",
        data_inicio_prevista: tratamentoExperimentalConsultado?.data_inicio_prevista || "",
        resultado_esperado: tratamentoExperimentalConsultado?.resultado_esperado || "",
        descrição: tratamentoExperimentalConsultado?.descrição || "",
        necessita_equipamento_especial: tratamentoExperimentalConsultado?.necessita_equipamento_especial || false,
        alto_risco: tratamentoExperimentalConsultado?.alto_risco || false 
    });
    
    const [erros, setErros] = useState({});
    const navegar = useNavigate();

    const opçõesTipoCâncerAlvo = [
        { label: "Pulmão", value: "pulmão" },
        { label: "Mama", value: "mama" },
        { label: "Próstata", value: "próstata" },
        { label: "Leucemia", value: "leucemia" },
        { label: "Pele", value: "pele" }
    ];

    const opçõesFasePesquisa = [
        { label: "Pré-clínica", value: "pré_clínica" },
        { label: "Fase 1", value: "fase_1" },
        { label: "Fase 2", value: "fase_2" },
        { label: "Fase 3", value: "fase_3" }
    ];

    const opçõesResultadoEsperado = [
        { label: "Remissão Completa", value: "remissão_completa" },
        { label: "Redução do Tumor", value: "redução_tumor" },
        { label: "Aumento da Sobrevida", value: "aumento_sobrevida" }
    ];

    function alterarEstado(event) {
        const chave = event.target.name; 
        const valor = event.checked ?? event.target.value;
        setDados({ ...dados, [chave]: valor }); 
    };

    function validarCampos() {
        const { título, tipo_câncer_alvo, fase_pesquisa, data_inicio_prevista, resultado_esperado, descrição } = dados; 
        let errosCamposObrigatórios = validarCamposObrigatórios({ título, tipo_câncer_alvo, fase_pesquisa, data_inicio_prevista, resultado_esperado, descrição }); 
        setErros(errosCamposObrigatórios); 
        return checarListaVazia(errosCamposObrigatórios); 
    };

    function retornarAdministrarTratamentosExperimentais() { 
        navegar("../administrar-tratamentos-experimentais"); 
    }; 

    async function cadastrarTratamentoExperimental() { 
        if (validarCampos()) {
            try {
                await serviçoCadastrarTratamentoExperimental({ ...dados, cpf: usuárioLogado.cpf }); 
                mostrarToast(referênciaToast, "Tratamento Experimental cadastrado com sucesso!", "sucesso"); 
            } catch (error) { mostrarToast(referênciaToast, error.response.data.erro, "error"); } 
        }
    };

    async function alterarTratamentoExperimental() { 
        if (validarCampos()) { 
            try {
                await serviçoAlterarTratamentoExperimental({ ...dados, id: tratamentoExperimentalConsultado.id }); 
                mostrarToast(referênciaToast, "Tratamento Experimental alterado com sucesso!", "sucesso"); 
            } catch (error) { mostrarToast(referênciaToast, error.response.data.erro, "error"); } 
        }
    };

    async function removerTratamentoExperimental() { 
        try {
            await serviçoRemoverTratamentoExperimental(tratamentoExperimentalConsultado.id); 
            mostrarToast(referênciaToast, "Tratamento Experimental excluído com sucesso!", "sucesso"); 
        } catch (error) { mostrarToast(referênciaToast, error.response.data.erro, "error"); } 
    };

    function BotõesAções() { 
        if (tratamentoExperimentalConsultado) { 
            return ( 
                <div className={estilizarInlineFlex()}> 
                    <Button className={estilizarBotãoRetornar()} label="Retornar"
                        onClick={retornarAdministrarTratamentosExperimentais} /> 
                    <Button className={estilizarBotãoRemover()} label="Remover" onClick={removerTratamentoExperimental} /> 
                    <Button className={estilizarBotão()} label="Alterar" onClick={alterarTratamentoExperimental} /> 
                </div> 
            );
        } else { 
            return ( 
                <div className={estilizarInlineFlex()}> 
                    <Button className={estilizarBotãoRetornar()} label="Retornar"
                        onClick={retornarAdministrarTratamentosExperimentais} /> 
                    <Button className={estilizarBotão()} label="Cadastrar" onClick={cadastrarTratamentoExperimental} /> 
                </div> 
            );
        }
    };

    function tituloFormulario() { 
        if (tratamentoExperimentalConsultado) return "Alterar Tratamento Experimental"; 
        else return "Cadastrar Tratamento Experimental"; 
    };

    return (
        <div className={estilizarFlex()}> 
            <Toast ref={referênciaToast} onHide={retornarAdministrarTratamentosExperimentais} position="bottom-center" /> 
            <Card title={tituloFormulario()} className={estilizarCard(usuárioLogado.cor_tema)}> 
                
                <div className={estilizarDivCampo()}> 
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Título*:</label> 
                    <InputText name="título"
                        className={estilizarInputText(erros.título, 400, usuárioLogado.cor_tema)}
                        value={dados.título} onChange={alterarEstado} /> 
                    <MostrarMensagemErro mensagem={erros.título} /> 
                </div>

                <div className={estilizarDivCampo()}> 
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Tipo de Câncer Alvo*:</label>
                    <Dropdown name="tipo_câncer_alvo"
                        className={estilizarDropdown(erros.tipo_câncer_alvo, usuárioLogado.cor_tema)}
                        value={dados.tipo_câncer_alvo} options={opçõesTipoCâncerAlvo} onChange={alterarEstado}
                        placeholder="-- Selecione --" /> 
                    <MostrarMensagemErro mensagem={erros.tipo_câncer_alvo} /> 
                </div>

                <div className={estilizarDivCampo()}> 
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Fase da Pesquisa*:</label>
                    <Dropdown name="fase_pesquisa"
                        className={estilizarDropdown(erros.fase_pesquisa, usuárioLogado.cor_tema)}
                        value={dados.fase_pesquisa} options={opçõesFasePesquisa} onChange={alterarEstado}
                        placeholder="-- Selecione --" /> 
                    <MostrarMensagemErro mensagem={erros.fase_pesquisa} /> 
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Data de Início Prevista*:</label>
                    <InputText name="data_inicio_prevista" type="date" value={dados.data_inicio_prevista}
                        className={estilizarInputText(erros.data_inicio_prevista, 200, usuárioLogado.cor_tema)}
                        onChange={alterarEstado} />
                    <MostrarMensagemErro mensagem={erros.data_inicio_prevista} />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Resultado Esperado*:</label>
                    <Dropdown name="resultado_esperado"
                        className={estilizarDropdown(erros.resultado_esperado, usuárioLogado.cor_tema)}
                        value={dados.resultado_esperado} options={opçõesResultadoEsperado} onChange={alterarEstado}
                        placeholder="-- Selecione --" />
                    <MostrarMensagemErro mensagem={erros.resultado_esperado} />
                </div>

                <div className={estilizarDivCampo()}> 
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Descrição*:</label>
                    <InputTextarea name="descrição" value={dados.descrição}
                        className={estilizarInputTextarea(erros.descrição, usuárioLogado.cor_tema)}
                        onChange={alterarEstado} autoResize cols={40} /> 
                    <MostrarMensagemErro mensagem={erros.descrição} /> 
                </div>

                <div className={estilizarDivCampo()}> 
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Necessita Equipamento Especial:</label>
                    <Checkbox name="necessita_equipamento_especial" checked={dados.necessita_equipamento_especial}
                        className={estilizarCheckbox()} onChange={alterarEstado} />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Alto Risco:</label>
                    <Checkbox name="alto_risco" checked={dados.alto_risco}
                        className={estilizarCheckbox()} onChange={alterarEstado} />
                </div>

                <Divider className={estilizarDivider()} /> 
                <BotõesAções /> 
            </Card> 
        </div> 
    );
}