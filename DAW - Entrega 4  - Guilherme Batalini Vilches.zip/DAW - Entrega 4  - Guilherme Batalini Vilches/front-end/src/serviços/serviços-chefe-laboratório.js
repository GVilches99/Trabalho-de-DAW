import servidor from "./servidor";

// Funções da Entrega 2
export function serviçoCadastrarChefeLaboratório(dadosChefeLaboratório) {
    return servidor.post("/chefes-laboratorio", dadosChefeLaboratório);
};

export function serviçoBuscarChefeLaboratório(cpf) {
    return servidor.get(`/chefes-laboratorio/${cpf}`);
};

export function serviçoAtualizarChefeLaboratório(dadosChefeLaboratório) {
    return servidor.patch("/chefes-laboratorio", dadosChefeLaboratório);
};

// Funções da Entrega 3
export function serviçoCadastrarTratamentoExperimental(tratamento_experimental) {
    return servidor.post("/chefes-laboratorio/tratamentos-experimentais", tratamento_experimental);
};

export function serviçoAlterarTratamentoExperimental(tratamento_experimental) {
    return servidor.patch("/chefes-laboratorio/tratamentos-experimentais", tratamento_experimental);
};

export function serviçoRemoverTratamentoExperimental(id) {
    return servidor.delete(`/chefes-laboratorio/tratamentos-experimentais/${id}`);
};

export function serviçoBuscarTratamentosExperimentaisChefeLaboratório(cpf) {
   
    return servidor.get(`/chefes-laboratorio/tratamentos-experimentais/chefe-laboratorio/${cpf}`);
};

export function serviçoBuscarReservasAlaTratamento(id_tratamento_experimental) {
    return servidor.get(`/chefes-laboratorio/reservas-ala/${id_tratamento_experimental}`);
};