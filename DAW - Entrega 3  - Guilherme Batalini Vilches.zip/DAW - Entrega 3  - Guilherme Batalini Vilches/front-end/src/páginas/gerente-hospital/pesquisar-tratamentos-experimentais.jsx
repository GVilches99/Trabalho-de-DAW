import { useContext, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Divider } from "primereact/divider";
import { Dropdown } from "primereact/dropdown";
import { Toast } from "primereact/toast";
import { TriStateCheckbox } from "primereact/tristatecheckbox";
import ContextoUsuário from "../../contextos/contexto-usuário";
import ContextoGerenteHospital from "../../contextos/contexto-gerente-hospital";
import { serviçoBuscarTratamentosExperimentais } from "../../serviços/serviços-gerente-hospital";
import mostrarToast from "../../utilitários/mostrar-toast";
import { 
    TAMANHOS, estilizarBotãoRetornar, estilizarBotãoTabela, estilizarCard,
    estilizarColumnHeader, estilizarColunaConsultar, estilizarDataTable, estilizarDataTablePaginator,
    estilizarDivider, estilizarFilterMenu, estilizarFlex, estilizarTriStateCheckbox 
} from "../../utilitários/estilos";

export default function PesquisarTratamentosExperimentais() {
    const referênciaToast = useRef(null);
    const { usuárioLogado } = useContext(ContextoUsuário);
    const { tratamentoExperimentalConsultado, setTratamentoExperimentalConsultado, setTratamentoExperimentalSelecionado }
        = useContext(ContextoGerenteHospital);
    const [listaTratamentosExperimentais, setListaTratamentosExperimentais] = useState([]);
    const navegar = useNavigate();

    const opçõesTipoCâncerAlvo = [
        { label: "Pulmão", value: "pulmão" },
        { label: "Mama", value: "mama" },
        { label: "Próstata", value: "próstata" },
        { label: "Leucemia", value: "leucemia" },
        { label: "Pele", value: "pele" }
    ];

    const opçõesFasePesquisa = [
        { label: "Pré-clínica", value: "pré_clínica" },
        { label: "Fase 1", value: "fase_1" },
        { label: "Fase 2", value: "fase_2" },
        { label: "Fase 3", value: "fase_3" }
    ];

    function retornarCadastrarReservaAla() {
        setTratamentoExperimentalSelecionado(tratamentoExperimentalConsultado);
        setTratamentoExperimentalConsultado(null);
        navegar("../cadastrar-reserva-ala");
    };

    function ConsultarTemplate(tratamento_experimental) {
        return (
            <Button icon="pi pi-search"
                className={estilizarBotãoTabela(usuárioLogado.cor_tema,
                    tratamentoExperimentalConsultado?.id === tratamento_experimental.id)}
                tooltip="Consultar Tratamento Experimental" tooltipOptions={{ position: 'top' }}
                onClick={() => {
                    setTratamentoExperimentalConsultado(tratamento_experimental);
                    navegar("../consultar-tratamento-experimental");
                }} />
        );
    };

    function DropdownTipoCâncerTemplate(opções) {
        function alterarFiltroDropdown(event) {
            return opções.filterCallback(event.value, opções.index);
        };
        return <Dropdown value={opções.value} options={opçõesTipoCâncerAlvo} placeholder="Selecione"
            onChange={alterarFiltroDropdown} showClear />;
    };

    function DropdownFasePesquisaTemplate(opções) {
        function alterarFiltroDropdown(event) {
            return opções.filterCallback(event.value, opções.index);
        };
        return <Dropdown value={opções.value} options={opçõesFasePesquisa} placeholder="Selecione"
            onChange={alterarFiltroDropdown} showClear />;
    };

    function BooleanBodyTemplate(tratamento_experimental) {
        if (tratamento_experimental.necessita_equipamento_especial) return "Sim";
        else return "Não";
    };

    function BooleanFilterTemplate(opções) {
        function alterarFiltroTriState(event) { return opções.filterCallback(event.value); };
        return (
            <div>
                <label>Necessita equipamento especial:</label>
                <TriStateCheckbox
                    className={estilizarTriStateCheckbox(usuárioLogado?.cor_tema)} value={opções.value}
                    onChange={alterarFiltroTriState} />
            </div>
        );
    };

    useEffect(() => {
        let desmontado = false;
        async function buscarTratamentosExperimentais() {
            try {
                const response = await serviçoBuscarTratamentosExperimentais();
                if (!desmontado && response.data) setListaTratamentosExperimentais(response.data);
            } catch (error) { 
                mostrarToast(referênciaToast, error.response.data.erro, "error");
            }
        }
        buscarTratamentosExperimentais();
        return () => desmontado = true;
    }, [usuárioLogado.cpf]);

    return (
        <div className={estilizarFlex()}>
            <Toast ref={referênciaToast} position="bottom-center" />
            <Card title="Pesquisar Tratamentos Experimentais" className={estilizarCard(usuárioLogado.cor_tema)}>
                <DataTable dataKey="id" size="small" paginator rows={TAMANHOS.MAX_LINHAS_TABELA}
                    emptyMessage="Nenhum tratamento experimental encontrado." value={listaTratamentosExperimentais}
                    responsiveLayout="scroll" breakpoint="490px" removableSort
                    className={estilizarDataTable()}
                    paginatorClassName={estilizarDataTablePaginator(usuárioLogado.cor_tema)}>
                    
                    <Column bodyClassName={estilizarColunaConsultar()} body={ConsultarTemplate}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} />
                    
                    <Column field="chefe_laboratório.usuário.nome" header="Chefe de Laboratório" filter
                        showFilterOperator={false}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} sortable />
                    
                    <Column field="título" header="Título" filter showFilterOperator={false}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} sortable />
                    
                    <Column headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)}
                        field="tipo_câncer_alvo" header="Tipo de Câncer Alvo" filter filterMatchMode="equals"
                        filterElement={DropdownTipoCâncerTemplate} showClearButton={false}
                        showFilterOperator={false} showFilterMatchModes={false}
                        filterMenuClassName={estilizarFilterMenu()} showFilterMenuOptions={false} sortable />
                    
                    <Column headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)}
                        field="fase_pesquisa" header="Fase da Pesquisa" filter filterMatchMode="equals"
                        filterElement={DropdownFasePesquisaTemplate} showClearButton={false}
                        showFilterOperator={false} showFilterMatchModes={false}
                        filterMenuClassName={estilizarFilterMenu()} showFilterMenuOptions={false} sortable />
                    
                    <Column field="necessita_equipamento_especial" header="Necessita Equipamento Especial" dataType="boolean" filter
                        showFilterOperator={false}
                        body={BooleanBodyTemplate} filterElement={BooleanFilterTemplate}
                        filterMatchMode="equals" showClearButton={false} showAddButton={false}
                        filterMenuClassName={estilizarFilterMenu()}
                        headerClassName={estilizarColumnHeader(usuárioLogado.cor_tema)} sortable />
                </DataTable>
                
                <Divider className={estilizarDivider()} />
                <Button className={estilizarBotãoRetornar()} label="Retornar"
                    onClick={retornarCadastrarReservaAla} />
            </Card>
        </div>
    );
}