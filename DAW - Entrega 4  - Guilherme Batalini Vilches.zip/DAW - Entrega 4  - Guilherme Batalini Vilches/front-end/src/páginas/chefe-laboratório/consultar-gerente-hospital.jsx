import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Divider } from "primereact/divider";
import { InputText } from "primereact/inputtext";
import ContextoUsuário from "../../contextos/contexto-usuário";
import ContextoChefeLaboratório from "../../contextos/contexto-chefe-laboratório";
import { 
    estilizarBotãoRetornar, estilizarCard, estilizarDivCampo, estilizarDivider,
    estilizarFlex, estilizarInlineFlex, estilizarInputText, estilizarLabel 
} from "../../utilitários/estilos";

export default function ConsultarGerenteHospital(){
    const { usuárioLogado } = useContext(ContextoUsuário);
    const { gerenteHospitalInteressado } = useContext(ContextoChefeLaboratório);
    
    const dados = {
        nome: gerenteHospitalInteressado?.usuário?.nome, 
        nome_hospital: gerenteHospitalInteressado?.nome_hospital,
        capacidade_leitos: gerenteHospitalInteressado?.capacidade_leitos,
        tipo_hospital: gerenteHospitalInteressado?.tipo_hospital,
        especialidade_médica: gerenteHospitalInteressado?.especialidade_médica
    };
    const navegar = useNavigate();

    function retornarConsultarReservaAla() { 
        navegar("../consultar-reserva-ala"); 
    };

    return (
        <div className={estilizarFlex()}>
            <Card title="Consultar Gerente de Hospital" className={estilizarCard(usuárioLogado.cor_tema)}>
                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Nome*:</label>
                    <InputText name="nome" className={estilizarInputText(null, 400, usuárioLogado.cor_tema)}
                        value={dados.nome} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Nome do Hospital*:</label>
                    <InputText name="nome_hospital" className={estilizarInputText(null, 300, usuárioLogado.cor_tema)}
                        value={dados.nome_hospital} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Capacidade de Leitos*:</label>
                    <InputText name="capacidade_leitos" className={estilizarInputText(null, 200, usuárioLogado.cor_tema)}
                        value={dados.capacidade_leitos} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Tipo de Hospital*:</label>
                    <InputText name="tipo_hospital" className={estilizarInputText(null, 200, usuárioLogado.cor_tema)}
                        value={dados.tipo_hospital} disabled />
                </div>

                <div className={estilizarDivCampo()}>
                    <label className={estilizarLabel(usuárioLogado.cor_tema)}>Especialidade Médica*:</label>
                    <InputText name="especialidade_médica" className={estilizarInputText(null, 200, usuárioLogado.cor_tema)}
                        value={dados.especialidade_médica} disabled />
                </div>
                
                <Divider className={estilizarDivider(usuárioLogado.cor_tema)} />
                <div className={estilizarInlineFlex()}>
                    <Button className={estilizarBotãoRetornar()} label="Retornar"
                        onClick={retornarConsultarReservaAla} />
                </div>
            </Card>
        </div>
    );
}