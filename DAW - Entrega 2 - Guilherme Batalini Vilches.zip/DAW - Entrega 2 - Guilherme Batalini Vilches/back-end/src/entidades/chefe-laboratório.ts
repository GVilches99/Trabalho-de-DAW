import { BaseEntity, Column, Entity, JoinColumn, OneToMany, OneToOne, PrimaryGeneratedColumn } from
    "typeorm";
import Usuário from "./usuário";
import TratamentoExperimental from "./tratamento-experimental";
@Entity("chefe_laboratório") 
export default class ChefeLaboratório extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;
    @Column()
    instituição_pesquisa: string;
    @Column()
    anos_experiência_pesquisa: number;
    @Column()
    área_formação: string;
    @OneToMany(() => TratamentoExperimental, (tratamento_experimental) => tratamento_experimental.chefe_laboratório)
    tratamentos_experimentais: TratamentoExperimental[];
    @OneToOne(() => Usuário, (usuário) => usuário.chefe_laboratório, { onDelete: "CASCADE" })
    @JoinColumn({ name: 'usuário_cpf' }) 
    usuário: Usuário;
}