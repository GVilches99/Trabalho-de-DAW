import { BaseEntity, Column, CreateDateColumn, Entity, OneToOne, PrimaryColumn } from "typeorm";
import ChefeLaboratório from "./chefe-laboratório";
import GerenteHospital from "./gerente-hospital";
export enum Perfil { 
    GERENTE_HOSPITAL = "gerente_hospital", 
    CHEFE_LABORATÓRIO = "chefe_laboratório" 
};
export enum Status { 
    PENDENTE = "pendente", 
    ATIVO = "ativo" 
};
export enum Cores {
    AMARELO = "yellow", ANIL = "indigo", AZUL = "blue", AZUL_PISCINA = "cyan",
    CINZA_ESCURO = "bluegray", LARANJA = "orange", ROSA = "pink", ROXO = "purple", VERDE = "green",
    VERDE_AZULADO = "teal"
};
@Entity("usuário")
export default class Usuário extends BaseEntity {
    @PrimaryColumn()
    cpf: string;
    @Column({ type: "enum", enum: Perfil })
    perfil: Perfil;
    @Column({ type: "enum", enum: Status, default: Status.PENDENTE })
    status: Status;
    @Column()
    nome: string;
    @Column()
    email: string;
    @Column()
    senha: string;
    @Column()
    questão: string;
    @Column()
    resposta: string;
    @Column({ type: "enum", enum: Cores })
    cor_tema: string;
    @OneToOne(() => ChefeLaboratório, (chefe_laboratório) => chefe_laboratório.usuário)
    chefe_laboratório: ChefeLaboratório;
    @OneToOne(() => GerenteHospital, (gerente_hospital) => gerente_hospital.usuário)
    gerente_hospital: GerenteHospital;
    @CreateDateColumn()
    data_criação: Date;
}